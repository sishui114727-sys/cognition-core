import { RISK } from '../action-policy.js';
import { buildXhhUrl } from '../hkey.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function strip(value) {
  return String(value || '')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

async function getJson(url, fetchImpl = fetch) {
  const res = await fetchImpl(url, {
    headers: {
      'user-agent': UA,
      referer: 'https://www.xiaoheihe.cn/',
      accept: 'application/json',
    },
    redirect: 'follow',
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data?.status !== 'ok') throw new Error(`XHH ${data?.status || 'failed'}: ${data?.msg || ''}`);
  return data.result;
}

export class XhhReadAdapter {
  constructor({ fetchImpl = fetch } = {}) {
    this.fetchImpl = fetchImpl;
  }

  async feed({ limit = 5, offset = 0 } = {}) {
    const n = Math.max(1, Math.min(20, Number(limit) || 5));
    const url = buildXhhUrl('/bbs/app/feeds', {
      pull: '0',
      offset: String(Math.max(0, Number(offset) || 0)),
      dw: '1920',
    });
    const result = await getJson(url, this.fetchImpl);
    const links = Array.isArray(result?.links) ? result.links : [];
    return {
      items: links.slice(0, n).map((item) => ({
        linkId: item.linkid,
        title: strip(item.title),
        summary: strip(item.description).slice(0, 160),
        author: item.user?.username || '',
        likes: item.up ?? null,
        comments: item.comment_num ?? null,
        createdAt: item.create_at ?? null,
        url: item.share_url || `https://www.xiaoheihe.cn/community/1/detail/${item.linkid}`,
      })),
    };
  }

  register(bus) {
    bus.register({
      name: 'xhh.feed',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'xhhRead',
      execute: ({ limit, offset }) => this.feed({ limit, offset }),
    });
    return bus;
  }
}
