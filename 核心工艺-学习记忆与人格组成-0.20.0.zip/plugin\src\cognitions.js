import { randomUUID } from 'node:crypto';
import { JsonlStore } from './jsonl.js';
import { validateCognition } from './schema.js';

function latestById(rows) {
  const map = new Map();
  for (const row of rows) {
    const prev = map.get(row.id);
    if (!prev || row.revision > prev.revision) map.set(row.id, row);
  }
  return map;
}

export class CognitionStore {
  constructor({ dataDir }) {
    this.store = new JsonlStore({ dataDir, fileName: 'cognitions.jsonl' });
    this.dataDir = dataDir;
  }

  async append(input) {
    const now = new Date().toISOString();
    const rows = await this.store.readAll();
    const existing = latestById(rows).get(input.id);
    const revision = input.revision ?? (existing ? existing.revision + 1 : 1);
    if (!existing && revision !== 1) throw new Error('first cognition revision must be 1');
    if (existing && revision !== existing.revision + 1) {
      throw new Error(`cognition revision must be ${existing.revision + 1}, got ${revision}`);
    }
    const cognition = validateCognition({
      ...input,
      schemaVersion: 1,
      id: input.id ?? `cog_${randomUUID()}`,
      revision,
      firstSeen: input.firstSeen ?? existing?.firstSeen ?? now,
      lastConfirmed: input.lastConfirmed ?? existing?.lastConfirmed ?? now,
      createdAt: input.createdAt ?? existing?.createdAt ?? now,
      updatedAt: input.updatedAt ?? now,
    });
    await this.store.append(cognition);
    return cognition;
  }

  async latest(id) {
    const rows = await this.store.readAll();
    return latestById(rows).get(id) ?? null;
  }

  async list({ scope, status, kind, limit = 100 } = {}) {
    const rows = await this.store.readAll();
    return [...latestById(rows).values()]
      .filter((row) => !scope || (row.scope.kind === scope.kind && row.scope.id === scope.id))
      .filter((row) => !status || row.status === status)
      .filter((row) => !kind || row.kind === kind)
      .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt))
      .slice(0, Math.max(0, limit));
  }

  async history(id) {
    const rows = await this.store.readAll();
    return rows.filter((row) => row.id === id).sort((a, b) => a.revision - b.revision);
  }

  async close() {
    await this.store.close();
  }
}
