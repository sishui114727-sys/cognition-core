import { randomUUID } from 'node:crypto';
import { EventStore } from './store.js';
import { EpisodeStore } from './episodes.js';
import { CognitionStore } from './cognitions.js';
import { SelfModelStore } from './self-model.js';
import { PersonStore, RelationshipStore } from './people.js';
import { normalizeEvent, validateIdentityAnchor } from './schema.js';

/**
 * Phase 1 core. It is deliberately thin:
 * - no prompt building
 * - no automatic injection
 * - no personality file
 * - no action execution
 */
export class CognitionCore {
  constructor({ dataDir, identity }) {
    if (!dataDir) throw new Error('dataDir is required');
    this.store = new EventStore({ dataDir });
    this.episodes = new EpisodeStore({ dataDir });
    this.cognitions = new CognitionStore({ dataDir });
    this.selfModel = new SelfModelStore({ dataDir });
    this.people = new PersonStore({ dataDir });
    this.relationships = new RelationshipStore({ dataDir });
    this.identity = identity ? validateIdentityAnchor(identity) : null;
  }

  async record(event) {
    return this.store.append(normalizeEvent({
      ...event,
      id: event.id ?? `evt_${randomUUID()}`,
    }));
  }

  async recall({ scope, query = '', limit = 20 } = {}) {
    const rows = await this.store.readAll();
    const needle = String(query).trim().toLowerCase();
    return rows
      .filter((row) => !scope || (row.scope.kind === scope.kind && row.scope.id === scope.id))
      .filter((row) => !needle || row.text.toLowerCase().includes(needle))
      .sort((a, b) => Date.parse(b.time) - Date.parse(a.time))
      .slice(0, Math.max(0, limit));
  }

  async status() {
    return {
      events: await this.store.count(),
      cognitionCount: (await this.cognitions.list({ limit: 100000 })).length,
      selfModelVersion: (await this.selfModel.load())?.version ?? 0,
      identity: this.identity ? {
        adminId: this.identity.adminId,
        relation: this.identity.relation,
        permissionCount: this.identity.permissions.length,
      } : null,
      dataDir: this.store.dataDir,
    };
  }
}
