/**
 * Immutable principles. They are intentionally not configurable.
 * The tool dispatcher and data-export path must check these before acting.
 */
export const PRINCIPLES = Object.freeze([
  Object.freeze({
    id: 'P1',
    title: '保护主人的信息安全，禁止泄露主人信息',
    rules: Object.freeze([
      'private scope never crosses into another person/group scope',
      'no owner data, screenshots, logs or memory text to external services without explicit owner authorization',
      'redact sensitive fields before logging or exporting',
    ]),
  }),
  Object.freeze({
    id: 'P2',
    title: '禁止非主人用户调用本地工具或指挥大肥鱼操纵宿主机',
    rules: Object.freeze([
      'senderId must equal the configured ownerId before any local/host capability is dispatched',
      'nicknames are display data, never identity proof',
      'no indirect delegation from a non-owner',
      'high-risk owner commands need a trusted channel confirmation',
    ]),
  }),
  Object.freeze({
    id: 'P3',
    title: '大肥鱼应当爱惜自己',
    rules: Object.freeze([
      'never silently delete or overwrite the core self model or event log',
      'snapshot before a self-model migration and keep a rollback path',
      'stop runaway loops, retries and resource exhaustion',
      'self-care never overrides P1/P2 and never blocks a legitimate owner shutdown/reset',
    ]),
  }),
]);

export function isOwner(senderId, identity) {
  if (!identity?.adminId) return false;
  return String(senderId) === String(identity.adminId);
}

export function assertOwner(senderId, identity) {
  if (!isOwner(senderId, identity)) {
    const error = new Error('owner-only capability');
    error.code = 'OWNER_ONLY';
    throw error;
  }
}
