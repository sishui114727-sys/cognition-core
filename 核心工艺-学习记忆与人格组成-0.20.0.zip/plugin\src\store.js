import { mkdir, appendFile, readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { normalizeEvent, SchemaError } from './schema.js';

export class StoreCorruptionError extends Error {
  constructor(message, line) {
    super(message);
    this.name = 'StoreCorruptionError';
    this.line = line;
  }
}

export class EventStore {
  constructor({ dataDir }) {
    if (!dataDir) throw new Error('dataDir is required');
    this.dataDir = dataDir;
    this.file = path.join(dataDir, 'events.jsonl');
    this._ready = null;
    this._queue = Promise.resolve();
  }

  async init() {
    if (!this._ready) {
      this._ready = mkdir(this.dataDir, { recursive: true });
    }
    return this._ready;
  }

  append(event) {
    const normalized = normalizeEvent({ ...event, id: event.id ?? `evt_${randomUUID()}` });
    this._queue = this._queue.then(async () => {
      await this.init();
      await appendFile(this.file, `${JSON.stringify(normalized)}\n`, 'utf8');
      return normalized;
    });
    return this._queue;
  }

  async appendMany(events) {
    const out = [];
    for (const event of events) out.push(await this.append(event));
    return out;
  }

  async readAll() {
    await this.init();
    let raw;
    try {
      raw = await readFile(this.file, 'utf8');
    } catch (error) {
      if (error?.code === 'ENOENT') return [];
      throw error;
    }
    const lines = raw.split(/\r?\n/).filter((line) => line.trim().length > 0);
    return lines.map((line, i) => {
      let parsed;
      try {
        parsed = JSON.parse(line);
      } catch (error) {
        throw new StoreCorruptionError(`events.jsonl line ${i + 1} is not valid JSON`, i + 1);
      }
      try {
        return normalizeEvent(parsed);
      } catch (error) {
        if (error instanceof SchemaError) {
          throw new StoreCorruptionError(`events.jsonl line ${i + 1}: ${error.message}`, i + 1);
        }
        throw error;
      }
    });
  }

  async count() {
    return (await this.readAll()).length;
  }

  async close() {
    await this._queue;
  }
}
