﻿# QQA 顶栏「认知」模块说明

## 效果

QQ Agent 顶栏从：

```text
会话 | 用量 | 下载 | 工具 | 设置
```

变成：

```text
会话 | 用量 | 认知 | 下载 | 工具 | 设置
```

点「认知」后打开只读权限面板，和「用量」在同一级导航区。

## 为什么是只读

QQA 的插件页面通道是只读静态文件：

```text
/plugin-panel/<id>/...
  只能 GET
  不能 POST
  不能改配置
```

因此顶栏模块负责**看**，真正修改仍在插件设置表单里：

```text
QQA → 插件 → 认知核心 → ⚙ 设置
```

## 补丁改了什么

```text
ui/index.html
  + 顶栏「认知」按钮
  + 隐藏 tab 锚点 data-tab="cognition"
  + #view-cognition + iframe

ui/app/14-chrome.js
  + GROUPS 里增加 cognition 分组

ui/app/00-core.js
  + switchTab('cognition') 时懒加载 iframe

ui/style.css
  + iframe 全屏样式
```

iframe 地址：

```text
/plugin-panel/cognition-core/panel/overview.html
```

## 安装

```bash
node patch-qqa-ui.mjs --app-root "%LOCALAPPDATA%\Programs\QQ Agent"
```

脚本会：

1. 校验四个文件存在
2. 备份到 `dist/qqa-ui-backup-*`
3. 写入补丁
4. 已打补丁则直接退出

## 卸载

把备份目录里的四个文件复制回：

```text
resources/app/ui/index.html
resources/app/ui/style.css
resources/app/ui/app/14-chrome.js
resources/app/ui/app/00-core.js
```

然后重启 QQA。

## 注意

- QQA 升级会覆盖 `resources/app/ui`，需要重新打补丁
- 补丁只增加导航和只读页面，不改后端 API
- 如果 QQA 收在托盘，点托盘图标打开主窗口后才能看到顶栏
- 顶栏里的「认知」不负责写配置；写配置仍走设置表单
- 补丁不是插件市场条目，不能通过市场一键安装

