import { RISK } from '../action-policy.js';
import { checkContent, mentionsPersonOrChat } from '../safety/qzone-content.js';

export class QzonePublishAdapter {
  async publish({ ctx, content }) {
    if (!ctx?.onebot || typeof ctx.onebot.call !== 'function') {
      throw new Error('OneBot Qzone writer is unavailable');
    }
    const text = String(content || '').trim();
    if (!text) throw new Error('content is required');
    if (text.length > 500) throw new Error('content is too long (max 500)');

    const safe = checkContent(text);
    if (!safe.ok) throw new Error(`blocked content: ${safe.hit}`);
    const leak = mentionsPersonOrChat(text);
    if (leak) throw new Error(`content mentions a person or chat: ${leak}`);

    const response = await ctx.onebot.call('send_qzone_msg', {
      content: text,
      ugc_right: 4,
    });
    return {
      posted: true,
      visibility: 'friends',
      length: text.length,
      tid: response?.tid ?? response?.data?.tid ?? null,
    };
  }

  register(bus) {
    bus.register({
      name: 'qzone.publish',
      risk: RISK.PUBLIC,
      ownerOnly: true,
      feature: 'qzone',
      requiresConfirmation: true,
      execute: ({ ctx, content }) => this.publish({ ctx, content }),
    });
    return bus;
  }
}
