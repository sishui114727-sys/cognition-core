import { RISK } from '../action-policy.js';

export class QQPrivateAdapter {
  constructor({ ownerId }) {
    if (!ownerId) throw new Error('ownerId is required');
    this.ownerId = String(ownerId);
  }

  register(bus) {
    bus.register({
      name: 'chat.private.qq.send',
      risk: RISK.SOCIAL,
      ownerOnly: true,
      feature: 'privateChat',
      execute: async ({ ctx, target, text }) => {
        const to = String(target || this.ownerId);
        if (to !== this.ownerId) throw new Error('private target must be the owner');
        if (!ctx?.sender || typeof ctx.sender.sendTextBatch !== 'function') {
          throw new Error('QQ sender is unavailable');
        }
        if (typeof text !== 'string' || !text.trim()) throw new Error('text is required');
        if (text.length > 1000) throw new Error('text too long');
        const result = await ctx.sender.sendTextBatch(`private:${to}`, [{ type: 'text', text }], {});
        return { ok: true, target: to, messageId: result?.message_id ?? null };
      },
    });
    return bus;
  }
}
