﻿# cognition-core 社区安装说明

本包含两部分：

```text
plugin/     认知核心插件
patch/      QQA 顶栏「认知」模块补丁
```

## 1. 关闭 QQA

确认托盘里也没有 QQ Agent 在运行。

## 2. 安装插件

把 `plugin/` 复制到：

```text
<QQ Agent 安装目录>\resources\app\plugins\cognition-core
```

例如：

```text
%LOCALAPPDATA%\Programs\QQ Agent\resources\app\plugins\cognition-core
```

## 3. 打顶栏补丁

关闭 QQA 后运行：

```bash
node patch/patch-qqa-ui.mjs --app-root "%LOCALAPPDATA%\Programs\QQ Agent"
```

脚本会先备份：

```text
patch/dist/qqa-ui-backup-<时间>/
```

如果已经打过补丁，会直接跳过。

## 4. 启动并启用

1. 启动 QQ Agent
2. 打开「下载 → 已安装 → 插件」
3. 找到「认知核心」
4. 启用
5. 如果 QQA 提示信任插件，确认后再启用

启用后顶栏应出现：

```text
会话 | 用量 | 认知 | 下载 | 工具 | 设置
```

点「认知」即可打开只读权限面板。

## 5. 修改权限

面板是只读的。  
修改请到：

```text
插件 → 认知核心 → ⚙ 设置
```

那里有：

```text
主人 QQ 号
最高权限 L0–L4
11 个功能开关
时间窗
每日上限
每周上限
冷却
```

## 6. 恢复 UI

把 `patch/dist/qqa-ui-backup-<时间>/` 里的四个文件复制回：

```text
resources/app/ui/index.html
resources/app/ui/style.css
resources/app/ui/app/14-chrome.js
resources/app/ui/app/00-core.js
```

然后重启 QQA。

## 7. 注意

- QQA 升级会覆盖 `resources/app/ui`，补丁需重打
- 顶栏模块只读，不能绕过权限校验
- 插件默认 `enabledByDefault:false`，需要手动启用
- 没绑定主人 QQ 号时，本地/行动能力默认拒绝
- 不要把 `plugin-data/` 或真实聊天数据打进社区包


