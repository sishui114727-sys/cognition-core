import { JsonlStore } from './jsonl.js';
import { evaluateAction, ActionDeniedError, RISK } from './action-policy.js';

export class ActionBus {
  constructor({ dataDir, identity, gateway = null }) {
    this.dataDir = dataDir;
    this.identity = identity;
    this.gateway = gateway;
    this.capabilities = new Map();
    this.audit = new JsonlStore({ dataDir, fileName: 'action-log.jsonl' });
  }

  register(capability) {
    if (!capability?.name || typeof capability.name !== 'string') throw new Error('capability.name is required');
    if (typeof capability.execute !== 'function') throw new Error('capability.execute is required');
    if (!Number.isInteger(capability.risk) || capability.risk < RISK.READ || capability.risk > RISK.IRREVERSIBLE) {
      throw new Error('capability.risk must be 0..4');
    }
    if (this.capabilities.has(capability.name)) throw new Error(`duplicate capability: ${capability.name}`);
    this.capabilities.set(capability.name, Object.freeze({ ...capability }));
    return this;
  }

  async execute({ action, senderId, confirmed = false, origin = 'owner', target, ...payload }) {
    const capability = this.capabilities.get(action);
    const decision = evaluateAction({ capability, senderId, identity: this.identity, confirmed, origin });
    const base = {
      at: new Date().toISOString(),
      action: String(action ?? ''),
      actor: String(origin === 'self' ? 'self' : senderId ?? ''),
      origin,
      target: target ?? null,
      allowed: decision.allow,
      reason: decision.reason,
      risk: capability?.risk ?? null,
      feature: capability?.feature ?? null,
    };
    if (!decision.allow) {
      await this.audit.append(base);
      throw new ActionDeniedError(decision.reason);
    }
    if (this.gateway && capability?.feature) {
      const gate = await this.gateway.check({ feature: capability.feature, at: new Date() });
      if (!gate.allowed) {
        const reason = `gateway:${gate.reason}`;
        await this.audit.append({ ...base, allowed: false, reason, gate });
        throw new ActionDeniedError(reason);
      }
    }
    try {
      const result = await capability.execute({ target, confirmed, senderId, ...payload });
      let gatewayRecorded = true;
      if (this.gateway && capability?.feature) {
        try {
          await this.gateway.record({
            feature: capability.feature,
            action,
            actor: origin === 'self' ? 'self' : senderId,
          });
        } catch {
          gatewayRecorded = false;
        }
      }
      await this.audit.append({ ...base, ok: true, gatewayRecorded });
      return result;
    } catch (error) {
      await this.audit.append({ ...base, ok: false, error: error?.name || 'Error' });
      throw error;
    }
  }

  async close() {
    await this.audit.close();
  }
}
