import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { CognitionCore } from './core.js';
import { ActionBus } from './action-bus.js';
import { Gateway } from './gateway.js';
import { policyFromSettings } from './gateway-policy.js';
import { buildContextPack } from './context-pack.js';
import { QQStickerAdapter } from './adapters/qq-sticker.js';
import { QQPrivateAdapter } from './adapters/qq-private.js';
import { BiliReadAdapter } from './adapters/bili.js';
import { XhhReadAdapter } from './adapters/xhh.js';
import { QzoneReadAdapter } from './adapters/qzone.js';
import { QzonePublishAdapter } from './adapters/qzone-publish.js';

let apiRef = null;
let hostState = null;
const pendingPeople = new Map();

function rememberPeople(chatKey, entries) {
  const people = [];
  for (const entry of Array.isArray(entries) ? entries : []) {
    if (!entry || entry.self) continue;
    const id = String(entry.senderId || entry.userId || '').trim();
    if (!id) continue;
    people.push({ id, name: String(entry.senderName || '').trim() });
  }
  if (!people.length) return;
  if (pendingPeople.size > 64) {
    const cutoff = Date.now() - 10 * 60000;
    for (const [key, value] of pendingPeople) {
      if (!value || value.at < cutoff) pendingPeople.delete(key);
    }
  }
  pendingPeople.set(chatKey, { at: Date.now(), people: people.slice(0, 2) });
}

function impressionAllowed(eventScope, currentScope) {
  if (!currentScope) return false;
  if (currentScope.kind === 'group') return eventScope?.kind === 'group';
  return eventScope?.kind === 'group' || eventScope?.kind === 'global' || eventScope?.kind === 'person';
}

async function appendPersonCard(state, ctx, lastUser) {
  if (state.settings.injectPersonCardEnabled === false) return;
  const chatKey = String(ctx.chatKey || '');
  if (!chatKey || !lastUser) return;
  if (lastUser.content.includes('【这个人你也认识】')) return;
  const pending = pendingPeople.get(chatKey);
  pendingPeople.delete(chatKey);
  if (!pending?.people?.length) return;
  const currentScope = scopeFromChatKey(chatKey);
  if (!currentScope) return;

  try {
    if (!state.personIndex) {
      const file = path.join(state.core.store.dataDir, 'person-cards.json');
      const data = JSON.parse(await readFile(file, 'utf8'));
      state.personIndex = data?.people || {};
    }
    const lines = [];
    for (const person of pending.people) {
      const profile = await state.core.people.get(person.id);
      if (!profile) continue;
      const impressions = (state.personIndex[person.id] || [])
        .filter((row) => impressionAllowed(row.scope, currentScope))
        .sort((a, b) => Number(b.at) - Number(a.at))
        .slice(0, 2)
        .map((row) => String(row.text).slice(0, 140));
      if (!impressions.length) continue;
      const name = profile.displayName || person.name || person.id;
      lines.push(`【这个人你也认识】${name}(QQ:${person.id}) · 现在是${currentScope.kind === 'group' ? '群聊' : '私聊'}`);
      for (const text of impressions) lines.push(`· ${text}`);
      if (currentScope.kind === 'group') lines.push('· 群聊复述时不要带出他的私聊内容。');
    }
    if (!lines.length) return;
    lastUser.content += `\n\n${lines.join('\n')}`;
  } catch (error) {
    apiRef?.warn?.('跨会话认人注入失败：', error?.message ?? error);
  }
}

export const providers = {
  'status.cognition-core': () => hostState?.snapshot() ?? {
    enabled: false,
    reason: 'not-active',
  },
};

function scopeFromChatKey(chatKey) {
  const value = String(chatKey || '');
  const match = /^(group|private)(?::|_)(.+)$/.exec(value);
  if (!match) return null;
  return match[1] === 'group'
    ? { kind: 'group', id: match[2] }
    : { kind: 'person', id: match[2] };
}

async function resolveCoreDataDir() {
  try {
    const mod = await import('../../../src/config.js');
    return path.join(mod.DATA_DIR, 'plugin-data', 'cognition-core', 'core');
  } catch {
    const root = process.env.QQ_AGENT_DATA_DIR || path.join(process.cwd(), 'data');
    return path.join(root, 'plugin-data', 'cognition-core', 'core');
  }
}

export function createHost({ api, settings, dataDir }) {
  const policy = policyFromSettings(settings);
  const identity = settings.adminId
    ? { adminId: String(settings.adminId), relation: 'owner' }
    : null;
  const core = new CognitionCore({ dataDir, identity });
  const gateway = new Gateway({ policy, dataDir });
  const bus = new ActionBus({ dataDir, identity, gateway });
  const dataRoot = path.resolve(dataDir, '../../..');
  let personIndex = null;
  try {
    personIndex = JSON.parse(readFileSync(path.join(dataDir, 'person-cards.json'), 'utf8'))?.people || {};
  } catch {
    personIndex = null;
  }
  new QQStickerAdapter({ dataRoot }).register(bus);
  new BiliReadAdapter().register(bus);
  new XhhReadAdapter().register(bus);
  new QzoneReadAdapter().register(bus);
  new QzonePublishAdapter().register(bus);
  if (identity) new QQPrivateAdapter({ ownerId: identity.adminId }).register(bus);
  const injection = {
    enabled: settings.injectContextEnabled === true,
    maxTokens: Math.max(100, Math.min(2000, Number(settings.injectContextTokens) || 600)),
    maxItems: Math.max(1, Math.min(8, Number(settings.injectContextMaxItems) || 3)),
  };

  return {
    core,
    gateway,
    bus,
    policy,
    settings,
    injection,
    dataRoot,
    personIndex,
    snapshot() {
      return {
        ...gateway.snapshot(),
        updatedAt: new Date().toISOString(),
        events: null,
        injection,
      };
    },
    async close() {
      await bus.close();
      await gateway.close();
      await core.store.close();
      await core.episodes.close();
      await core.cognitions.close();
      await core.selfModel.close();
      await core.people.close();
      await core.relationships.close();
    },
  };
}

function publishSnapshot(api, state) {
  try {
    api.storage.set('snapshot', state.snapshot());
  } catch (error) {
    api.warn('权限面板快照写入失败：', error?.message ?? error);
  }
}

export const hooks = {
  async 'before-context'(ctx = {}) {
    if (!hostState) return;
    const chatKey = String(ctx.chatKey || '');
    if (!chatKey) return;
    rememberPeople(chatKey, ctx.triggerEntries);
  },

  async 'after-response'(ctx = {}) {
    const state = hostState;
    if (!state || state.settings.recordDialogue === false) return;
    const chatKey = String(ctx.chatKey || '');
    const scope = scopeFromChatKey(chatKey);
    const content = ctx?.response?.message?.content;
    if (!scope || typeof content !== 'string' || !content.trim()) return;
    const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
    const userText = trigger
      .filter((entry) => entry && !entry.self)
      .map((entry) => String(entry.text || '').trim())
      .filter(Boolean)
      .join('\n')
      .slice(0, 4000);
    if (!userText) return;
    const eventId = `dialogue:${chatKey}:${Date.now()}`;
    const participants = trigger
      .filter((entry) => entry && !entry.self && entry.senderId)
      .map((entry) => ({ id: String(entry.senderId), role: 'speaker' }));
    try {
      await state.core.store.append({
        id: eventId,
        time: new Date().toISOString(),
        scope,
        source: { type: 'dialogue', id: eventId, ref: chatKey },
        participants,
        text: `${userText}\n→ ${content.trim().slice(0, 4000)}`,
        confidence: 0.8,
        salience: 0.5,
        privacy: scope.kind === 'group' ? 'group' : 'private',
        metadata: { chatKey },
      });
    } catch (error) {
      apiRef?.warn?.('对话事件写入失败：', error?.message ?? error);
    }
  },

  /**
   * Optional, default-off, small ContextPack injection.
   * It appends to the last user message, never to the system prompt, and
   * never injects the full SelfModel or full history.
   */
  async 'before-llm-messages'(ctx = {}) {
    const state = hostState;
    if (!state) return;
    const chatKey = String(ctx.chatKey || '');
    if (!chatKey) return;
    const messages = Array.isArray(ctx.messages) ? ctx.messages : null;
    if (!messages?.length) return;
    const lastUser = [...messages].reverse().find((m) => m?.role === 'user' && typeof m.content === 'string');
    if (!lastUser) return;
    const scope = scopeFromChatKey(chatKey);
    if (!scope) return;

    await appendPersonCard(state, ctx, lastUser);
    if (!state.injection.enabled) return;
    if (lastUser.content.includes('【认知上下文】')) return;

    try {
      const query = lastUser.content.replace(/【认知上下文】[\s\S]*$/, '').trim().slice(0, 300);
      const [events, cognitions] = await Promise.all([
        state.core.recall({ scope, query, limit: 30 }),
        state.core.cognitions.list({ scope, limit: 30 }),
      ]);
      const pack = buildContextPack({
        events,
        cognitions,
        scope,
        query,
        budget: {
          maxTokens: state.injection.maxTokens,
          maxChars: Math.min(3000, state.injection.maxTokens * 2),
          maxItems: state.injection.maxItems,
          maxEventChars: 180,
          maxCognitionChars: 220,
        },
      });
      if (!pack.text) return;
      lastUser.content += `\n\n【认知上下文】\n${pack.text}`;
    } catch (error) {
      // A failed optional injection must not break the conversation.
      apiRef?.warn?.('认知上下文注入失败：', error?.message ?? error);
    }
  },
};

function registerTools(api) {
  api.registerTool({
    id: 'cognition_status',
    name: '认知核心状态',
    description: '只读查看当前权限等级、功能开关、时间窗和日/周限制。不要用它修改配置。',
    category: 'knowledge',
    parameters: { type: 'object', properties: {} },
    async execute() {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      return { content: JSON.stringify(hostState.snapshot(), null, 1) };
    },
  });

  api.registerTool({
    id: 'cognition_qzone_publish',
    name: '发QQ空间说说',
    description: '把一条文本发到自己的 QQ 空间，好友可见。只有主人明确要求并确认后才能调用；会做时政/隐私过滤，不发图、不评论。',
    category: 'message',
    parameters: {
      type: 'object',
      properties: {
        content: { type: 'string', description: '说说正文，最多 500 字。' },
        confirmed: { type: 'boolean', description: '必须由主人明确确认才传 true。' },
      },
      required: ['content', 'confirmed'],
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      if (args?.confirmed !== true) return { content: '需要主人明确确认后才能发空间。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'qzone.publish',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          confirmed: true,
          ctx,
          content: args?.content,
        });
        return { content: JSON.stringify(result, null, 1) };
      } catch (error) {
        return { content: `发空间失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_qzone_read',
    name: '读自己的QQ空间',
    description: '只读读取自己的 QQ 空间说说和评论，复用宿主 OneBot 登录，不发帖、不评论。只有主人触发可用。',
    category: 'web',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: '读取几条说说，默认 5，上限 10' },
      },
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'qzone.read',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          ctx,
          limit: args?.limit,
        });
        return { content: JSON.stringify(result, null, 1) };
      } catch (error) {
        return { content: `QQ空间读取失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_xhh_feed',
    name: '读小黑盒信息流',
    description: '只读小黑盒社区信息流，返回帖子标题、摘要、作者、点赞/评论数和链接。只有主人触发可用。',
    category: 'web',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: '返回条数，默认 5，上限 20' },
        offset: { type: 'number', description: '分页偏移，默认 0' },
      },
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'xhh.feed',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          limit: args?.limit,
          offset: args?.offset,
        });
        return { content: JSON.stringify(result, null, 1) };
      } catch (error) {
        return { content: `小黑盒读取失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_bili_search',
    name: '搜 B 站视频',
    description: '只读搜索 B 站视频，返回标题、UP 主、播放量、时长和 BV 链接。只有主人触发可用。',
    category: 'web',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '搜索关键词' },
        count: { type: 'number', description: '返回条数，默认 5，上限 20' },
      },
      required: ['keyword'],
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'bili.search',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          keyword: args?.keyword,
          count: args?.count,
        });
        return { content: JSON.stringify(result, null, 1) };
      } catch (error) {
        return { content: `B站搜索失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_bili_video',
    name: '读 B 站视频信息',
    description: '只读读取一个 B 站视频的标题、UP 主、播放/点赞、简介和链接。只有主人触发可用。',
    category: 'web',
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '形如 BV1xx411c7mD' },
      },
      required: ['bvid'],
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'bili.video',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          bvid: args?.bvid,
        });
        return { content: JSON.stringify(result, null, 1) };
      } catch (error) {
        return { content: `B站读取失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_private_send',
    name: '给主人发私聊',
    description: '只给主人 QQ 发一条私聊文本。只有主人触发、且 adminId 已绑定时可用；不给其他人发。',
    category: 'message',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string', description: '要发送的文本，最多 1000 字。' },
      },
      required: ['text'],
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'chat.private.qq.send',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          ctx,
          target: hostState.settings.adminId,
          text: args?.text,
        });
        return { content: JSON.stringify(result) };
      } catch (error) {
        return { content: `发送失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_self',
    name: '读取自我模型',
    description: '只读读取当前 SelfModel：价值、承诺、边界、未解问题与自我叙事。不自动注入，不修改。',
    category: 'knowledge',
    parameters: { type: 'object', properties: {} },
    async execute() {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      const model = await hostState.core.selfModel.load();
      if (!model) return { content: '还没有 SelfModel。', isError: true };
      return { content: JSON.stringify(model, null, 1) };
    },
  });

  api.registerTool({
    id: 'cognition_sticker_send',
    name: '发送 QQ 表情',
    description: '从宿主 QQ 表情库发送一个表情。只有主人私聊/群聊的明确触发可以调用；没有表情 id 时使用库里第一个。',
    category: 'sticker',
    parameters: {
      type: 'object',
      properties: {
        stickerId: { type: 'string', description: '可选：表情 id；不填使用第一个。' },
      },
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      if (!hostState.settings.adminId) return { content: '请先在设置里绑定主人 QQ 号。', isError: true };
      if (!ctx?.triggerSenderId) return { content: '没有可验证的触发者。', isError: true };
      try {
        const result = await hostState.bus.execute({
          action: 'sticker.qq.send',
          senderId: ctx.triggerSenderId,
          origin: 'owner',
          ctx,
          stickerId: args?.stickerId,
        });
        return { content: JSON.stringify(result) };
      } catch (error) {
        return { content: `发送失败：${error?.message ?? error}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'cognition_recall',
    name: '回忆认知',
    description: '按当前会话范围检索少量相关事件与认知，返回有预算的上下文包；不注入完整人格或完整历史。',
    category: 'knowledge',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '检索关键词；可为空。' },
        limit: { type: 'number', description: '最多返回条数，默认 8。' },
      },
    },
    async execute(ctx, args) {
      if (!hostState) return { content: '认知核心未启用。', isError: true };
      const scope = scopeFromChatKey(ctx?.chatKey);
      const query = String(args?.query || '');
      const limit = Math.max(1, Math.min(20, Number(args?.limit) || 8));
      const events = await hostState.core.recall({ scope, query, limit: 50 });
      const cognitions = await hostState.core.cognitions.list({ scope, limit: 50 });
      const pack = buildContextPack({
        events,
        cognitions,
        scope,
        query,
        budget: { maxTokens: 900, maxItems: limit },
      });
      return {
        content: pack.text || '没有找到相关记忆。',
        metadata: {
          scope,
          estimatedTokens: pack.estimatedTokens,
          truncated: pack.truncated,
        },
      };
    },
  });
}

export function setup(api) {
  apiRef = api;
  registerTools(api);
}

export async function activate(options = {}) {
  if (!apiRef) throw new Error('cognition-core setup() was not called');
  const settings = apiRef.config() || {};
  if (settings.enabled === false) {
    apiRef.log('认知核心已关闭');
    return;
  }
  const dataDir = options.dataDir ? path.resolve(options.dataDir) : await resolveCoreDataDir();
  hostState = createHost({ api: apiRef, settings, dataDir });
  publishSnapshot(apiRef, hostState);
  apiRef.log(`认知核心已启用：权限 L${hostState.policy.permissionLevel}，时区 ${hostState.policy.timeZone}`);
}

export async function deactivate() {
  if (hostState) {
    await hostState.close();
    hostState = null;
  }
}

export function available() {
  return Boolean(apiRef) && apiRef.config?.()?.enabled !== false;
}
