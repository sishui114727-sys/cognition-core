import { RISK } from '../action-policy.js';

/**
 * A side-effect-free adapter for tests, demos and community release.
 * It never touches the host, network or a real platform.
 */
export class MockAdapter {
  constructor({ name = 'mock.echo', risk = RISK.LOW } = {}) {
    this.name = name;
    this.risk = risk;
  }

  register(bus) {
    bus.register({
      name: this.name,
      risk: this.risk,
      ownerOnly: true,
      execute: async (payload) => ({ ok: true, adapter: this.name, payload }),
    });
    return bus;
  }
}
