import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { normalizeEvent } from './schema.js';

export class LegacyImportError extends Error {
  constructor(message, file = '') {
    super(file ? `${file}: ${message}` : message);
    this.name = 'LegacyImportError';
    this.file = file;
  }
}

function scopeFromChatKey(chatKey, file) {
  const value = String(chatKey || '');
  const match = /^(group|private)(?::|_)(.+)$/.exec(value);
  if (!match) throw new LegacyImportError(`unsupported chatKey: ${value}`, file);
  return match[1] === 'group'
    ? { kind: 'group', id: match[2] }
    : { kind: 'person', id: match[2] };
}

function privacyFromScope(scope) {
  return scope.kind === 'group' ? 'group' : 'private';
}

function timeOf(value, file) {
  const n = typeof value === 'string' ? Date.parse(value) : Number(value);
  if (!Number.isFinite(n)) throw new LegacyImportError('missing/invalid timestamp', file);
  return new Date(n < 1e12 ? n * 1000 : n).toISOString();
}

async function listJsonFiles(dir) {
  const out = [];
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch (error) {
    if (error?.code === 'ENOENT') return out;
    throw error;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await listJsonFiles(full));
    else if (entry.isFile() && entry.name.endsWith('.json')) out.push(full);
  }
  return out.sort();
}

async function readJson(file) {
  let raw;
  try {
    raw = await readFile(file, 'utf8');
  } catch (error) {
    throw new LegacyImportError(`read failed: ${error.message}`, file);
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    throw new LegacyImportError(`invalid JSON: ${error.message}`, file);
  }
}

function makeEvent(input) {
  return normalizeEvent({
    schemaVersion: 1,
    ...input,
  });
}

async function existingIds(store) {
  const rows = await store.readAll();
  return new Set(rows.map((row) => row.id));
}

/**
 * Import mem-layered hour/day blocks as one event per block.
 * The source tree is never written.
 */
export async function importMemoryLayered({ sourceDir, store, dryRun = false, maxEvents = Infinity }) {
  const files = await listJsonFiles(path.join(sourceDir, 'blocks'));
  const ids = dryRun ? new Set() : await existingIds(store);
  const events = [];
  for (const file of files) {
    if (events.length >= maxEvents) break;
    const block = await readJson(file);
    if (!block?.id) throw new LegacyImportError('block has no id', file);
    const id = `legacy:mem-layered:${block.id}`;
    if (ids.has(id)) continue;
    const scope = scopeFromChatKey(block.chatKey, file);
    const event = makeEvent({
      id,
      time: timeOf(block.when, file),
      scope,
      source: { type: 'legacy-mem-layered', id: block.id, ref: file },
      participants: [],
      text: block.summary || block.title || `legacy block ${block.id}`,
      summary: block.summary,
      confidence: 0.45,
      salience: 0.5,
      privacy: privacyFromScope(scope),
      metadata: {
        legacyKind: block.kind,
        chatKey: block.chatKey,
        dayKey: block.dayKey,
        hourKey: block.hourKey,
        keywords: Array.isArray(block.keywords) ? block.keywords.slice(0, 64) : [],
        snippetCount: Array.isArray(block.snippets) ? block.snippets.length : 0,
      },
    });
    if (dryRun) {
      events.push(event);
    } else {
      events.push(await store.append(event));
    }
  }
  return events;
}

/**
 * Import cross-memory records as events. Supports both {memories:[...]} and [...].
 */
export async function importCrossMemory({ sourceDir, store, dryRun = false, maxEvents = Infinity }) {
  const file = path.join(sourceDir, 'memories.json');
  const data = await readJson(file);
  const rows = Array.isArray(data) ? data : data?.memories;
  if (!Array.isArray(rows)) throw new LegacyImportError('memories.json has no memories array', file);
  const ids = dryRun ? new Set() : await existingIds(store);
  const events = [];
  for (const row of rows) {
    if (events.length >= maxEvents) break;
    if (!row?.id || !row?.text) throw new LegacyImportError('memory has no id/text', file);
    const id = `legacy:cross-memory:${row.id}`;
    if (ids.has(id)) continue;
    const scope = scopeFromChatKey(row.chatKey, file);
    const event = makeEvent({
      id,
      time: timeOf(row.ts, file),
      scope,
      source: { type: 'legacy-cross-memory', id: row.id, ref: file },
      participants: [],
      text: row.text,
      confidence: 0.5,
      salience: row.emotion ? 0.65 : 0.45,
      privacy: privacyFromScope(scope),
      metadata: {
        emotion: row.emotion,
        base: row.base,
        kind: row.kind,
        recallCount: row.recallCount,
        lastRecallAt: row.lastRecallAt,
        chatKey: row.chatKey,
      },
    });
    if (dryRun) {
      events.push(event);
    } else {
      events.push(await store.append(event));
    }
  }
  return events;
}

/**
 * Import life-events. Handles {events:[...]} and single plan objects.
 */
export async function importLifeEvents({ sourceDir, store, dryRun = false, maxEvents = Infinity }) {
  const files = await listJsonFiles(sourceDir);
  const ids = dryRun ? new Set() : await existingIds(store);
  const events = [];
  for (const file of files) {
    if (events.length >= maxEvents) break;
    const data = await readJson(file);
    const base = path.basename(file).split('.')[0];
    const scope = scopeFromChatKey(base, file);
    const sourceRef = file;
    const rows = Array.isArray(data?.events) ? data.events : [data];
    for (const row of rows) {
      if (events.length >= maxEvents) break;
      const text = row?.text
        || [row?.day, row?.weather, row?.twist].filter(Boolean).join('；')
        || '';
      if (!text) throw new LegacyImportError('life record has no text', file);
      const legacyId = row?.id || `${base}:${row?.at || 'plan'}`;
      const id = `legacy:life-memory:${legacyId}`;
      if (ids.has(id)) continue;
      const event = makeEvent({
        id,
        time: timeOf(row?.at ?? row?.touchedAt ?? Date.now(), file),
        scope,
        source: { type: 'legacy-life-memory', id: legacyId, ref: sourceRef },
        participants: [],
        text,
        confidence: 0.5,
        salience: row?.ongoing ? 0.7 : 0.4,
        privacy: privacyFromScope(scope),
        metadata: {
          ongoing: row?.ongoing === true,
          touchedAt: row?.touchedAt,
          legacyId,
        },
      });
      if (dryRun) {
        events.push(event);
      } else {
        events.push(await store.append(event));
      }
    }
  }
  return events;
}

export async function importAllLegacy({ dataRoot, store, dryRun = false, maxEvents = Infinity }) {
  const result = { memory: [], cross: [], life: [] };
  result.memory = await importMemoryLayered({
    sourceDir: path.join(dataRoot, 'memory-v3'),
    store,
    dryRun,
    maxEvents,
  });
  result.cross = await importCrossMemory({
    sourceDir: path.join(dataRoot, 'cross-memory'),
    store,
    dryRun,
    maxEvents: Math.max(0, maxEvents - result.memory.length),
  });
  result.life = await importLifeEvents({
    sourceDir: path.join(dataRoot, 'life-events'),
    store,
    dryRun,
    maxEvents: Math.max(0, maxEvents - result.memory.length - result.cross.length),
  });
  return {
    counts: {
      memory: result.memory.length,
      cross: result.cross.length,
      life: result.life.length,
      total: result.memory.length + result.cross.length + result.life.length,
    },
    events: [...result.memory, ...result.cross, ...result.life],
  };
}
