import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { RISK } from '../action-policy.js';

/**
 * Real QQ sticker adapter.
 * It reads the host's stickers.json and calls ctx.sender.sendSticker.
 * It is owner-only through ActionBus and only runs inside a tool call that
 * already has a sender context.
 */
export class QQStickerAdapter {
  constructor({ dataRoot }) {
    this.dataRoot = path.resolve(dataRoot);
    this.file = path.join(this.dataRoot, 'stickers.json');
  }

  async load() {
    const data = JSON.parse(await readFile(this.file, 'utf8'));
    if (!Array.isArray(data)) throw new Error('stickers.json is not an array');
    return data.filter((sticker) => sticker && sticker.id && (sticker.url || sticker.localFile));
  }

  async choose(stickerId) {
    const stickers = await this.load();
    if (stickerId) {
      const found = stickers.find((sticker) => String(sticker.id) === String(stickerId));
      if (!found) throw new Error('sticker not found');
      return found;
    }
    if (!stickers.length) throw new Error('sticker library is empty');
    return stickers[0];
  }

  register(bus) {
    bus.register({
      name: 'sticker.qq.send',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'sticker',
      execute: async ({ ctx, stickerId }) => {
        if (!ctx?.sender || typeof ctx.sender.sendSticker !== 'function') {
          throw new Error('QQ sender is unavailable');
        }
        if (!ctx.chatKey) throw new Error('chatKey is missing');
        const sticker = await this.choose(stickerId);
        const result = await ctx.sender.sendSticker(ctx.chatKey, sticker, {
          replyToMessageId: null,
          atUserId: null,
        });
        return {
          ok: true,
          stickerId: sticker.id,
          messageId: result?.message_id ?? null,
        };
      },
    });
    return bus;
  }
}
