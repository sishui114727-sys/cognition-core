import { RISK } from '../action-policy.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function buvid3() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, () => Math.floor(Math.random() * 16).toString(16)) + 'infoc';
}

function stripTags(value) {
  return String(value || '').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}

function makeHeaders() {
  return {
    'user-agent': UA,
    referer: 'https://www.bilibili.com/',
    accept: 'application/json',
    cookie: `buvid3=${buvid3()}`,
  };
}

async function getJson(url, fetchImpl = fetch) {
  const res = await fetchImpl(url, {
    headers: makeHeaders(),
    redirect: 'follow',
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) {
    const hint = res.status === 412 || res.status === 403 ? '（B站风控，稍后重试）' : '';
    throw new Error(`HTTP ${res.status}${hint}`);
  }
  const data = await res.json();
  if (data?.code !== 0) {
    const hint = data?.code === -412 || data?.code === -403 ? '（B站风控，稍后重试）' : '';
    throw new Error(`code=${data?.code} ${data?.message || ''}${hint}`);
  }
  return data.data;
}

export class BiliReadAdapter {
  constructor({ fetchImpl = fetch } = {}) {
    this.fetchImpl = fetchImpl;
  }

  async search({ keyword, count = 5 }) {
    const kw = String(keyword || '').trim();
    if (!kw) throw new Error('keyword is required');
    const n = Math.max(1, Math.min(20, Number(count) || 5));
    const url = `https://api.bilibili.com/x/web-interface/search/type?search_type=video&page=1&keyword=${encodeURIComponent(kw)}`;
    const data = await getJson(url, this.fetchImpl);
    const arr = Array.isArray(data?.result) ? data.result : [];
    return {
      total: Number(data?.numResults) || arr.length,
      items: arr.slice(0, n).map((v) => ({
        bvid: v.bvid || '',
        title: stripTags(v.title),
        author: v.author || '',
        play: v.play ?? null,
        duration: v.duration || '',
        url: v.bvid ? `https://www.bilibili.com/video/${v.bvid}` : (v.arcurl || ''),
      })),
    };
  }

  async video({ bvid }) {
    const id = String(bvid || '').trim();
    if (!/^BV[0-9A-Za-z]+$/.test(id)) throw new Error('bvid must look like BV...');
    try {
      const data = await getJson(`https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(id)}`, this.fetchImpl);
      return {
        bvid: data.bvid,
        title: data.title,
        author: data.owner?.name || '',
        duration: data.duration,
        publishedAt: data.pubdate,
        play: data.stat?.view ?? null,
        like: data.stat?.like ?? null,
        desc: String(data.desc || '').slice(0, 500),
        url: `https://www.bilibili.com/video/${data.bvid}`,
      };
    } catch (error) {
      // The view endpoint sometimes bans anonymous requests with -412.
      // The search endpoint accepts the exact BV id and returns enough
      // metadata for a read-only lookup, so use it as a fallback.
      const found = await this.search({ keyword: id, count: 10 });
      const hit = found.items.find((item) => item.bvid === id);
      if (!hit) throw error;
      return {
        bvid: hit.bvid,
        title: hit.title,
        author: hit.author,
        duration: hit.duration,
        publishedAt: null,
        play: hit.play,
        like: null,
        desc: '',
        url: hit.url,
        source: 'search',
      };
    }
  }

  register(bus) {
    bus.register({
      name: 'bili.search',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'biliRead',
      execute: ({ keyword, count }) => this.search({ keyword, count }),
    });
    bus.register({
      name: 'bili.video',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'biliRead',
      execute: ({ bvid }) => this.video({ bvid }),
    });
    return bus;
  }
}
