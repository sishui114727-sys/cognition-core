import { normalizeScope } from './schema.js';

export const DEFAULT_CONTEXT_BUDGET = Object.freeze({
  maxTokens: 1200,
  maxChars: 3000,
  maxItems: 8,
  maxCognitionChars: 240,
  maxEventChars: 300,
});

/**
 * Heuristic only. Chinese text is close to 1 token/char, while English is
 * closer to 4 chars/token. 0.8 is deliberately conservative for mixed text.
 * Hosts with an exact tokenizer should replace this estimate.
 */
export function estimateTokens(text) {
  return Math.ceil([...String(text)].length * 0.8);
}

function clip(text, max) {
  const chars = [...String(text)];
  return chars.length <= max ? String(text) : `${chars.slice(0, max).join('')}…`;
}

function rankCognition(row, query) {
  const statusScore = row.status === 'stable' ? 100 : row.status === 'contested' ? 20 : 0;
  const queryScore = query && row.statement.toLowerCase().includes(query) ? 30 : 0;
  return statusScore + queryScore + row.confidence * 10;
}

function rankEvent(row, query) {
  const queryScore = query && row.text.toLowerCase().includes(query) ? 30 : 0;
  return queryScore + row.salience * 10;
}

/**
 * Build a small context pack. It never injects a full persona or full history.
 * It does not call a model.
 */
export function buildContextPack({
  events = [],
  cognitions = [],
  scope,
  query = '',
  budget = {},
} = {}) {
  const limits = { ...DEFAULT_CONTEXT_BUDGET, ...budget };
  const wantedScope = scope ? normalizeScope(scope) : null;
  const needle = String(query).trim().toLowerCase();

  const scoped = (row) => !wantedScope
    || (row.scope.kind === wantedScope.kind && row.scope.id === wantedScope.id);

  const cognitionItems = [...cognitions]
    .filter(scoped)
    .filter((row) => row.status !== 'retired')
    .sort((a, b) => rankCognition(b, needle) - rankCognition(a, needle))
    .map((row) => ({
      type: 'cognition',
      id: row.id,
      text: `C: ${clip(row.statement, limits.maxCognitionChars)} (confidence=${row.confidence.toFixed(2)})`,
      source: row,
    }));

  const eventItems = [...events]
    .filter(scoped)
    .sort((a, b) => rankEvent(b, needle) - rankEvent(a, needle)
      || Date.parse(b.time) - Date.parse(a.time))
    .map((row) => ({
      type: 'event',
      id: row.id,
      text: `E: ${clip(row.summary || row.text, limits.maxEventChars)}`,
      source: row,
    }));

  // Stable cognition first, then recent/relevant events.
  const candidates = [...cognitionItems, ...eventItems];
  const seen = new Set();
  const selected = [];
  const lines = [];
  let chars = 0;
  let tokens = 0;
  let truncated = false;

  for (const item of candidates) {
    if (selected.length >= limits.maxItems) {
      truncated = true;
      break;
    }
    if (seen.has(item.id)) {
      truncated = true;
      continue;
    }
    const nextChars = chars + (lines.length ? 1 : 0) + item.text.length;
    const nextTokens = estimateTokens(lines.length ? `${lines.join('\n')}\n${item.text}` : item.text);
    if (nextChars > limits.maxChars || nextTokens > limits.maxTokens) {
      truncated = true;
      continue;
    }
    seen.add(item.id);
    lines.push(item.text);
    chars = nextChars;
    tokens = nextTokens;
    selected.push(item);
  }

  return {
    text: lines.join('\n'),
    items: selected.map(({ type, id }) => ({ type, id })),
    chars,
    estimatedTokens: tokens,
    truncated,
    scope: wantedScope,
    budget: Object.freeze({ ...limits }),
  };
}
