export const PERMISSION_LEVELS = Object.freeze([
  { value: 0, label: 'L0 · 只读', description: '只允许读取和回复，不允许主动社交或发布。' },
  { value: 1, label: 'L1 · 低风险', description: '允许表情、音乐、学习阅读等低风险动作。' },
  { value: 2, label: 'L2 · 社交', description: '允许私聊、群内接话；仍需时间窗和频率限制。' },
  { value: 3, label: 'L3 · 公共表达', description: '允许评论、空间、头像等公开动作；默认关闭，需明确开启。' },
  { value: 4, label: 'L4 · 高影响', description: '允许视频发布、桌面操作等不可逆动作；默认关闭。' },
]);

export const FEATURES = Object.freeze([
  {
    key: 'sticker', label: '表情', category: 'expression', level: 1,
    limited: true, defaultEnabled: true,
    defaults: { start: '00:00', end: '23:59', dailyLimit: 0, weeklyLimit: 0, cooldownMin: 0 },
    description: '从本地表情库选择并发送；默认每日/每周无限制。0 = 无限制。',
  },
  {
    key: 'music', label: '音乐', category: 'expression', level: 1,
    limited: false, defaultEnabled: true,
    description: '从本地音乐库选择并播放；不包含外部平台写入。',
  },
  {
    key: 'privateChat', label: '主动私聊', category: 'social', level: 2,
    limited: true, defaultEnabled: true,
    defaults: { start: '08:00', end: '23:30', dailyLimit: 20, weeklyLimit: 100, cooldownMin: 5 },
    description: '主动发起私聊；受时间窗、日/周上限和冷却限制。',
  },
  {
    key: 'groupChat', label: '群内接话', category: 'social', level: 2,
    limited: true, defaultEnabled: true,
    defaults: { start: '08:00', end: '23:30', dailyLimit: 40, weeklyLimit: 250, cooldownMin: 2 },
    description: '在群里主动接话；受时间窗、日/周上限和冷却限制。',
  },
  {
    key: 'biliRead', label: 'B站学习/观看', category: 'read', level: 1,
    limited: false, defaultEnabled: true,
    description: '读取视频、字幕、抽帧和学习材料；不包含评论/点赞。',
  },
  {
    key: 'qzoneRead', label: 'QQ空间只读', category: 'read', level: 1,
    limited: false, defaultEnabled: true,
    description: '只读自己的空间说说与评论；复用宿主 OneBot，不重写登录，不发帖/评论。',
  },
  {
    key: 'xhhRead', label: '小黑盒只读', category: 'read', level: 1,
    limited: false, defaultEnabled: true,
    description: '只读小黑盒社区信息流；不登录、不评论、不发帖。',
  },
  {
    key: 'biliComment', label: 'B站评论/弹幕', category: 'publish', level: 3,
    limited: true, defaultEnabled: false,
    defaults: { start: '10:00', end: '22:00', dailyLimit: 3, weeklyLimit: 10, cooldownMin: 60 },
    description: '公开评论或弹幕；默认关闭，受严格时间和频率限制。',
  },
  {
    key: 'xiaohihe', label: '小黑盒发帖/评论', category: 'publish', level: 3,
    limited: true, defaultEnabled: false,
    defaults: { start: '10:00', end: '23:00', dailyLimit: 2, weeklyLimit: 7, cooldownMin: 120 },
    description: '小黑盒公开内容；默认关闭，建议只在明确授权时开启。',
  },
  {
    key: 'qzone', label: 'QQ空间发布/评论', category: 'publish', level: 3,
    limited: true, defaultEnabled: false,
    defaults: { start: '09:00', end: '23:00', dailyLimit: 2, weeklyLimit: 7, cooldownMin: 120 },
    description: 'QQ空间公开内容；默认关闭。',
  },
  {
    key: 'avatar', label: '更换头像', category: 'public', level: 3,
    limited: true, defaultEnabled: false,
    defaults: { start: '00:00', end: '23:59', dailyLimit: 1, weeklyLimit: 2, cooldownMin: 1440 },
    description: '修改 QQ 头像；默认关闭。',
  },
  {
    key: 'video', label: '发布视频', category: 'publish', level: 4,
    limited: true, defaultEnabled: false,
    defaults: { start: '10:00', end: '22:00', dailyLimit: 1, weeklyLimit: 2, cooldownMin: 1440 },
    description: '制作并发布视频；默认关闭，高影响动作。',
  },
  {
    key: 'desktop', label: '桌面操作', category: 'device', level: 4,
    limited: false, defaultEnabled: false,
    description: '操作本机桌面；默认关闭，必须使用隔离账户或沙箱。',
  },
]);

export const FEATURE_MAP = Object.freeze(new Map(FEATURES.map((feature) => [feature.key, feature])));

const HHMM = /^([01]\d|2[0-3]):([0-5]\d)$/;

function assert(condition, message, path) {
  if (!condition) {
    const error = new Error(path ? `${path}: ${message}` : message);
    error.name = 'PolicyError';
    throw error;
  }
}

function normalizeFeature(key, value) {
  const meta = FEATURE_MAP.get(key);
  assert(Boolean(meta), `unknown feature: ${key}`, 'features');
  const defaults = meta.defaults || {};
  const enabled = value?.enabled === undefined ? meta.defaultEnabled : Boolean(value.enabled);
  const start = value?.window?.start ?? defaults.start ?? '00:00';
  const end = value?.window?.end ?? defaults.end ?? '23:59';
  const dailyLimit = Number(value?.dailyLimit ?? defaults.dailyLimit ?? 0);
  const weeklyLimit = Number(value?.weeklyLimit ?? defaults.weeklyLimit ?? 0);
  const cooldownMin = Number(value?.cooldownMin ?? defaults.cooldownMin ?? 0);
  if (meta.limited) {
    assert(HHMM.test(start), 'window.start must be HH:mm', `features.${key}.window.start`);
    assert(HHMM.test(end), 'window.end must be HH:mm', `features.${key}.window.end`);
    assert(Number.isInteger(dailyLimit) && dailyLimit >= 0, 'dailyLimit must be an integer >= 0', `features.${key}.dailyLimit`);
    assert(Number.isInteger(weeklyLimit) && weeklyLimit >= 0, 'weeklyLimit must be an integer >= 0', `features.${key}.weeklyLimit`);
    assert(Number.isFinite(cooldownMin) && cooldownMin >= 0, 'cooldownMin must be >= 0', `features.${key}.cooldownMin`);
    if (weeklyLimit > 0) {
      assert(dailyLimit <= weeklyLimit, 'dailyLimit cannot exceed weeklyLimit', `features.${key}.dailyLimit`);
    }
  }
  return Object.freeze({
    enabled,
    level: meta.level,
    ...(meta.limited ? {
      window: Object.freeze({ start, end }),
      dailyLimit,
      weeklyLimit,
      cooldownMin,
    } : {}),
  });
}

export function defaultPolicy() {
  return normalizePolicy({
    enabled: true,
    permissionLevel: 2,
    timeZone: 'Asia/Hong_Kong',
    features: {},
  });
}

export function normalizePolicy(input = {}) {
  const permissionLevel = Number(input.permissionLevel ?? 2);
  assert(Number.isInteger(permissionLevel) && permissionLevel >= 0 && permissionLevel <= 4, 'permissionLevel must be 0..4', 'permissionLevel');
  const enabled = input.enabled === undefined ? true : Boolean(input.enabled);
  const timeZone = String(input.timeZone ?? 'Asia/Hong_Kong');
  try {
    new Intl.DateTimeFormat('en-CA', { timeZone }).format(new Date());
  } catch {
    assert(false, `invalid timeZone: ${timeZone}`, 'timeZone');
  }
  const features = {};
  for (const meta of FEATURES) {
    features[meta.key] = normalizeFeature(meta.key, input.features?.[meta.key]);
  }
  return Object.freeze({
    schemaVersion: 1,
    enabled,
    permissionLevel,
    timeZone,
    features: Object.freeze(features),
  });
}

/** Convert the flat QQA configSchema settings into a canonical policy. */
export function policyFromSettings(settings = {}) {
  const features = {};
  for (const meta of FEATURES) {
    const prefix = meta.key;
    const entry = {
      enabled: settings[`${prefix}Enabled`] === undefined ? meta.defaultEnabled : Boolean(settings[`${prefix}Enabled`]),
    };
    if (meta.limited) {
      const d = meta.defaults;
      entry.window = {
        start: String(settings[`${prefix}WindowStart`] ?? d.start),
        end: String(settings[`${prefix}WindowEnd`] ?? d.end),
      };
      entry.dailyLimit = Number(settings[`${prefix}DailyLimit`] ?? d.dailyLimit);
      entry.weeklyLimit = Number(settings[`${prefix}WeeklyLimit`] ?? d.weeklyLimit);
      entry.cooldownMin = Number(settings[`${prefix}CooldownMin`] ?? d.cooldownMin);
    }
    features[prefix] = entry;
  }
  return normalizePolicy({
    enabled: settings.enabled,
    permissionLevel: settings.permissionLevel,
    timeZone: settings.timeZone,
    features,
  });
}

/** Flat settings for generated configSchema / settings. */
export function settingsFromPolicy(policy = defaultPolicy()) {
  const settings = {
    enabled: policy.enabled,
    permissionLevel: policy.permissionLevel,
    timeZone: policy.timeZone,
  };
  for (const meta of FEATURES) {
    const feature = policy.features[meta.key];
    settings[`${meta.key}Enabled`] = feature.enabled;
    if (meta.limited) {
      settings[`${meta.key}WindowStart`] = feature.window.start;
      settings[`${meta.key}WindowEnd`] = feature.window.end;
      settings[`${meta.key}DailyLimit`] = feature.dailyLimit;
      settings[`${meta.key}WeeklyLimit`] = feature.weeklyLimit;
      settings[`${meta.key}CooldownMin`] = feature.cooldownMin;
    }
  }
  return settings;
}

export function permissionLabel(level) {
  return PERMISSION_LEVELS.find((row) => row.value === Number(level))?.label ?? `L${level}`;
}
