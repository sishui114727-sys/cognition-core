import { FEATURES, permissionLabel } from './gateway-policy.js';

export function buildPanelSnapshot(policy, { usage = null } = {}) {
  return {
    updatedAt: new Date().toISOString(),
    permissionLevel: policy.permissionLevel,
    permissionLabel: permissionLabel(policy.permissionLevel),
    timeZone: policy.timeZone,
    enabled: policy.enabled,
    features: FEATURES.map((meta) => {
      const feature = policy.features[meta.key];
      return {
        key: meta.key,
        label: meta.label,
        category: meta.category,
        description: meta.description,
        enabled: feature.enabled,
        level: feature.level,
        hardLevel: meta.level,
        limited: meta.limited,
        window: feature.window ?? null,
        dailyLimit: feature.dailyLimit ?? null,
        weeklyLimit: feature.weeklyLimit ?? null,
        cooldownMin: feature.cooldownMin ?? null,
        usage: usage?.[meta.key] ?? null,
      };
    }),
  };
}
