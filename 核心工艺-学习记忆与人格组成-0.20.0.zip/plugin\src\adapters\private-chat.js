import { RISK } from '../action-policy.js';

export class MockChatTransport {
  constructor() {
    this.sent = [];
  }

  async send({ target, text }) {
    const messageId = `mock_${this.sent.length + 1}`;
    this.sent.push({ messageId, target, text, at: new Date().toISOString() });
    return { messageId, target, at: this.sent.at(-1).at };
  }
}

export class PrivateChatAdapter {
  constructor({ transport, ownerId, allowedTargets = [] }) {
    if (!transport || typeof transport.send !== 'function') throw new Error('transport.send is required');
    if (!ownerId) throw new Error('ownerId is required');
    this.transport = transport;
    this.ownerId = String(ownerId);
    this.allowedTargets = new Set([String(ownerId), ...allowedTargets.map(String)]);
  }

  register(bus) {
    bus.register({
      name: 'chat.private.send',
      risk: RISK.SOCIAL,
      ownerOnly: true,
      feature: 'privateChat',
      execute: async ({ target, text }) => {
        const to = String(target ?? '');
        if (!this.allowedTargets.has(to)) throw new Error(`private chat target not allowed: ${to}`);
        if (typeof text !== 'string' || text.trim().length === 0) throw new Error('text is required');
        if (text.length > 4000) throw new Error('text too long');
        return this.transport.send({ target: to, text });
      },
    });
    return bus;
  }
}
