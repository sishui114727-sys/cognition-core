import { CognitionCore } from '../core.js';
import { ActionBus } from '../action-bus.js';
import { Gateway } from '../gateway.js';
import { StickerAdapter } from './sticker.js';
import { MusicAdapter } from './music.js';
import { PrivateChatAdapter, MockChatTransport } from './private-chat.js';

/**
 * Mock host composition. No QQ, no network, no desktop.
 * It exists to test the wiring and to show the expected host contract.
 */
export function createMockHost({
  dataDir,
  identity,
  stickerCatalog,
  musicCatalog,
  chatTransport = new MockChatTransport(),
  allowedChatTargets = [],
  policy = null,
}) {
  const core = new CognitionCore({ dataDir, identity });
  const gateway = policy ? new Gateway({ policy, dataDir }) : null;
  const bus = new ActionBus({ dataDir, identity, gateway });

  if (stickerCatalog) new StickerAdapter({ catalogFile: stickerCatalog }).register(bus);
  if (musicCatalog) new MusicAdapter({ catalogFile: musicCatalog }).register(bus);
  new PrivateChatAdapter({
    transport: chatTransport,
    ownerId: identity.adminId,
    allowedTargets: allowedChatTargets,
  }).register(bus);

  return {
    core,
    bus,
    gateway,
    chatTransport,
    async close() {
      await bus.close();
      if (gateway) await gateway.close();
      await core.store.close();
      await core.episodes.close();
      await core.cognitions.close();
      await core.selfModel.close();
    },
  };
}
