# Sticker Adapter Example

把 `catalog.example.json` 复制成 `catalog.json`，把 `hello.png` / `cat.png` 放进同目录。

```json
{
  "stickers": [
    { "id": "hello", "file": "hello.png", "tags": ["greeting"] }
  ]
}
```

用法：

```js
import { ActionBus, StickerAdapter } from 'cognition-core';

const bus = new ActionBus({ dataDir, identity });
new StickerAdapter({ catalogFile: './catalog.json' }).register(bus);

await bus.execute({
  action: 'sticker.send',
  senderId: 'self',
  origin: 'self',
  tags: ['greeting'],
});
```

Adapter 只返回文件路径和元数据，不发送到 QQ。  
真实发送由宿主 Adapter 完成。
