import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { RISK } from '../action-policy.js';

export class TrackNotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = 'TrackNotFoundError';
  }
}

export class MusicAdapter {
  constructor({ catalogFile, rootDir, maxBytes = 512 * 1024 * 1024 }) {
    if (!catalogFile) throw new Error('catalogFile is required');
    this.catalogFile = path.resolve(catalogFile);
    this.rootDir = path.resolve(rootDir ?? path.dirname(this.catalogFile));
    this.maxBytes = maxBytes;
    this._catalog = null;
  }

  async loadCatalog() {
    if (this._catalog) return this._catalog;
    const data = JSON.parse(await readFile(this.catalogFile, 'utf8'));
    if (!Array.isArray(data?.tracks)) throw new Error('catalog.tracks must be an array');
    const seen = new Set();
    const tracks = data.tracks.map((track, i) => {
      if (!track?.id || !track?.file) throw new Error(`catalog.tracks[${i}] needs id/file`);
      if (seen.has(track.id)) throw new Error(`duplicate track id: ${track.id}`);
      seen.add(track.id);
      return Object.freeze({
        id: String(track.id),
        file: String(track.file),
        title: String(track.title ?? track.id),
        artist: track.artist ? String(track.artist) : undefined,
        duration: Number(track.duration ?? 0),
        tags: Object.freeze(Array.isArray(track.tags) ? track.tags.map(String) : []),
      });
    });
    this._catalog = Object.freeze({ tracks: Object.freeze(tracks) });
    return this._catalog;
  }

  resolvePath(track) {
    const resolved = path.resolve(this.rootDir, track.file);
    const root = this.rootDir.endsWith(path.sep) ? this.rootDir : `${this.rootDir}${path.sep}`;
    if (resolved !== this.rootDir && !resolved.startsWith(root)) {
      throw new Error(`track path escapes root: ${track.file}`);
    }
    return resolved;
  }

  async select({ trackId, tags = [] } = {}) {
    const catalog = await this.loadCatalog();
    let chosen;
    if (trackId) {
      chosen = catalog.tracks.find((track) => track.id === trackId);
    } else {
      const wanted = new Set(tags);
      chosen = catalog.tracks
        .map((track) => ({ track, score: track.tags.filter((tag) => wanted.has(tag)).length }))
        .filter((row) => row.score > 0)
        .sort((a, b) => b.score - a.score)[0]?.track;
    }
    if (!chosen) throw new TrackNotFoundError('no matching track');
    const file = this.resolvePath(chosen);
    const info = await stat(file);
    if (!info.isFile()) throw new Error(`track is not a file: ${chosen.id}`);
    if (info.size > this.maxBytes) throw new Error(`track too large: ${chosen.id}`);
    return {
      kind: 'music',
      id: chosen.id,
      path: file,
      title: chosen.title,
      artist: chosen.artist,
      duration: chosen.duration,
    };
  }

  register(bus) {
    bus.register({
      name: 'music.play',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'music',
      execute: async ({ trackId, tags }) => this.select({ trackId, tags }),
    });
    return bus;
  }
}
