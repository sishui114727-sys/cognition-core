import { createHash } from 'node:crypto';

const CHARSET = 'AB45STUVWZEFGJ6CH01D237IXYPQRKLMN89';

function vm(e) {
  return e & 128 ? 255 & ((e << 1) ^ 27) : e << 1;
}

function qm(e) {
  return vm(e) ^ e;
}

function dollar(e) {
  return qm(vm(e));
}

function ym(e) {
  return dollar(qm(vm(e)));
}

function gm(e) {
  return ym(e) ^ dollar(e) ^ qm(e);
}

function km(values) {
  const e = [...values];
  const t = [0, 0, 0, 0];
  t[0] = gm(e[0]) ^ ym(e[1]) ^ dollar(e[2]) ^ qm(e[3]);
  t[1] = qm(e[0]) ^ gm(e[1]) ^ ym(e[2]) ^ dollar(e[3]);
  t[2] = dollar(e[0]) ^ qm(e[1]) ^ gm(e[2]) ^ ym(e[3]);
  t[3] = ym(e[0]) ^ dollar(e[1]) ^ qm(e[2]) ^ gm(e[3]);
  e[0] = t[0];
  e[1] = t[1];
  e[2] = t[2];
  e[3] = t[3];
  return e;
}

function mapChars(input, charset, length) {
  const alphabet = charset.slice(0, length);
  let out = '';
  for (const char of input) out += alphabet[char.charCodeAt(0) % alphabet.length];
  return out;
}

export function hkey(pathname, timestamp, nonce) {
  const parts = String(pathname).split('/').filter(Boolean);
  const normalized = '/' + parts.join('/') + '/';
  const components = [
    mapChars(String(timestamp), CHARSET, -2),
    mapChars(normalized, CHARSET, CHARSET.length),
    mapChars(nonce, CHARSET, CHARSET.length),
  ];
  const max = Math.max(...components.map((part) => part.length));
  let interleaved = '';
  for (let i = 0; i < max; i += 1) {
    for (const part of components) if (i < part.length) interleaved += part[i];
  }
  const digest = createHash('md5').update(interleaved.slice(0, 20)).digest('hex');
  const prefix = mapChars(digest.slice(0, 5), CHARSET, -4);
  const suffix = [...digest.slice(-6)].map((char) => char.charCodeAt(0));
  const checksum = km(suffix).reduce((sum, value) => sum + value, 0) % 100;
  return prefix + String(checksum).padStart(2, '0');
}

export function buildXhhUrl(pathname, params = {}) {
  const timestamp = Math.floor(Date.now() / 1000);
  const nonce = createHash('md5').update(`${Date.now()}${Math.random()}`).digest('hex').toUpperCase();
  const all = {
    os_type: 'web',
    app: 'heybox',
    client_type: 'web',
    version: '999.0.4',
    web_version: '2.5',
    x_client_type: 'web',
    x_app: 'heybox_website',
    heybox_id: '',
    x_os_type: 'Windows',
    device_info: 'Chrome',
    device_id: '2c2fef8385ccef915e3b3caf94e3aa06',
    ...params,
    hkey: hkey(pathname, timestamp, nonce),
    _time: timestamp,
    nonce,
  };
  return `https://api.xiaoheihe.cn${pathname}?${new URLSearchParams(all).toString()}`;
}
