import { mkdir, appendFile, readFile } from 'node:fs/promises';
import path from 'node:path';

export class JsonlCorruptionError extends Error {
  constructor(file, line, message) {
    super(`${file} line ${line}: ${message}`);
    this.name = 'JsonlCorruptionError';
    this.file = file;
    this.line = line;
  }
}

export class JsonlStore {
  constructor({ dataDir, fileName }) {
    if (!dataDir) throw new Error('dataDir is required');
    if (!fileName) throw new Error('fileName is required');
    this.dataDir = dataDir;
    this.file = path.join(dataDir, fileName);
    this._ready = null;
    this._queue = Promise.resolve();
  }

  async init() {
    if (!this._ready) this._ready = mkdir(this.dataDir, { recursive: true });
    return this._ready;
  }

  append(record) {
    const line = JSON.stringify(record);
    this._queue = this._queue.then(async () => {
      await this.init();
      await appendFile(this.file, `${line}\n`, 'utf8');
      return record;
    });
    return this._queue;
  }

  async readAll() {
    await this.init();
    let raw;
    try {
      raw = await readFile(this.file, 'utf8');
    } catch (error) {
      if (error?.code === 'ENOENT') return [];
      throw error;
    }
    const lines = raw.split(/\r?\n/).filter((line) => line.trim().length > 0);
    return lines.map((line, i) => {
      try {
        return JSON.parse(line);
      } catch (error) {
        throw new JsonlCorruptionError(this.file, i + 1, 'not valid JSON');
      }
    });
  }

  async count() {
    return (await this.readAll()).length;
  }

  async close() {
    await this._queue;
  }
}
