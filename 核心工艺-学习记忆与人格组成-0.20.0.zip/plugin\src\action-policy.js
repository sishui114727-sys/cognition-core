import { isOwner } from './principles.js';

export const RISK = Object.freeze({
  READ: 0,
  LOW: 1,
  SOCIAL: 2,
  PUBLIC: 3,
  IRREVERSIBLE: 4,
});

export const DEFAULT_CAPABILITY_POLICY = Object.freeze({
  ownerOnly: true,
  risk: RISK.READ,
  requiresConfirmation: false,
  egress: false,
  selfDestructive: false,
});

export class ActionDeniedError extends Error {
  constructor(reason) {
    super(`action denied: ${reason}`);
    this.name = 'ActionDeniedError';
    this.reason = reason;
  }
}

export function evaluateAction({ capability, senderId, identity, confirmed = false, origin = 'owner' }) {
  const policy = { ...DEFAULT_CAPABILITY_POLICY, ...capability };
  if (!capability?.name) return { allow: false, reason: 'unknown-capability' };
  if (origin !== 'owner' && origin !== 'self') {
    return { allow: false, reason: 'unknown-origin' };
  }
  // `self` means the cognition core initiated the action, not a non-owner user.
  // The host dispatcher must set origin; user input must never be able to set it.
  if (policy.ownerOnly && origin !== 'self' && !isOwner(senderId, identity)) {
    return { allow: false, reason: 'owner-only' };
  }
  if (policy.egress && !confirmed) {
    return { allow: false, reason: 'egress-requires-owner-confirmation' };
  }
  if (policy.selfDestructive && !confirmed) {
    return { allow: false, reason: 'self-destructive-requires-confirmation' };
  }
  if (policy.requiresConfirmation && !confirmed) {
    return { allow: false, reason: 'confirmation-required' };
  }
  if (policy.risk >= RISK.PUBLIC && !confirmed) {
    return { allow: false, reason: 'public-or-irreversible-requires-confirmation' };
  }
  return { allow: true, reason: 'allowed', policy };
}
