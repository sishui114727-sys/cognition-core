﻿# 公开发布说明

版本：0.20.0  
包名：`cognition-core-community-0.19.0.zip`

---

## 1. 发布包内容

```text
plugin/                 cognition-core 插件
patch/                  QQA 顶栏「认知」补丁
docs/                   核心说明、风险、冲突清单、协议
scripts/                导入/导出/扫描/构建脚本
INSTALL.md              安装说明
```

---

## 2. 不包含

```text
data/
events.jsonl
persons.jsonl
relationships.jsonl
cognitions.jsonl
self-model-versions.jsonl
action-log.jsonl
config.json
日志
聊天记录
QQ 号
Cookie / SESSDATA
图片/音乐/表情文件
绝对路径
`dist/public-data.example.json`
```

---

## 3. 公开数据不是自动上传

本包不包含：

```text
遥测 SDK
上传 endpoint
第三方统计
```

用户必须主动运行：

```bash
node scripts/public-data-export.mjs \
  --data-dir <core data> \
  --out public-data.json \
  --consent public-data-v1
```

才会生成匿名聚合文件。

协议：

```text
docs/数据收集协议.md
docs/CONSENT.zh-CN.md
```

---

## 4. 上传前必须替换

```text
docs/数据收集协议.md
  似水未来
  2736629638@qq.com
  QQ Agent 插件 cognition-core

docs/CONSENT.zh-CN.md
  维护者信息
```

未填写主体信息前，不要公开收集数据。

---

## 5. 发布前检查

```bash
node --test
node scripts/scan-release.mjs --dir <staging-dir> --owner-id <你的QQ> --allow-email 2736629638@qq.com
```

必须：

```text
tests pass
scan ok=true
```

人工再看：

```text
[ ] 没有 data/
[ ] 没有 events.jsonl
[ ] 没有 persons.jsonl
[ ] 没有 config.json
[ ] 没有 Cookie
[ ] 没有 QQ 号
[ ] 没有聊天截图
[ ] 没有绝对路径
[ ] 没有人设卡原文
[ ] 没有 public-data.example.json
[ ] 维护者信息已填写
```

---

## 6. 建议发布说明

```text
cognition-core 0.19.0

本地优先的 QQ Agent 认知/身份/权限核心。
不包含聊天数据，不包含遥测，默认不上传。
支持：Event/Person/Relationship/SelfModel、
认人卡片、权限 ActionBus、QQ 表情/私聊、
B站只读、小黑盒信息流、QQ空间只读/发布。

公开数据收集为自愿、匿名、聚合、k=5 抑制。
协议见 docs/数据收集协议.md。
```

---

## 7. 版本与回滚

```text
当前：0.19.0
上一版：0.18.0
回滚：保留旧 zip + data 备份 + config 备份
```

---

## 8. 不要发布

```text
dist/public-data.example.json
```

它来自本机真实使用数据。  
即使已聚合，也不应默认公开。

---

## 9. 许可与署名

发布前确认：

```text
LICENSE 存在
README 标明版本
CHANGELOG 更新
第三方代码/算法来源注明
平台适配器不承诺长期可用
```





