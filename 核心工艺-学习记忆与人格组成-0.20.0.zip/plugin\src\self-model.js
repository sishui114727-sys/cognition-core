import { JsonlStore } from './jsonl.js';
import { validateSelfModel } from './schema.js';

function changedFields(before, after) {
  const fields = ['values', 'commitments', 'boundaries', 'openQuestions', 'selfNarrative'];
  return fields.filter((field) => JSON.stringify(before?.[field] ?? null) !== JSON.stringify(after?.[field] ?? null));
}

export class SelfModelStore {
  constructor({ dataDir }) {
    this.store = new JsonlStore({ dataDir, fileName: 'self-model-versions.jsonl' });
    this.dataDir = dataDir;
  }

  async load() {
    const rows = await this.store.readAll();
    if (rows.length === 0) return null;
    return validateSelfModel(rows[rows.length - 1]);
  }

  async history() {
    return this.store.readAll();
  }

  async append(input) {
    const before = await this.load();
    const version = input.version ?? (before ? before.version + 1 : 1);
    if (before && version !== before.version + 1) {
      throw new Error(`self model version must be ${before.version + 1}, got ${version}`);
    }
    if (!before && version !== 1) throw new Error('first self model version must be 1');
    const candidate = {
      values: input.values ?? before?.values ?? [],
      commitments: input.commitments ?? before?.commitments ?? [],
      boundaries: input.boundaries ?? before?.boundaries ?? [],
      openQuestions: input.openQuestions ?? before?.openQuestions ?? [],
      selfNarrative: input.selfNarrative ?? before?.selfNarrative,
    };
    const changed = input.changedFields ?? changedFields(before, candidate);
    const model = validateSelfModel({
      schemaVersion: 1,
      version,
      ...candidate,
      updatedAt: input.updatedAt ?? new Date().toISOString(),
      change: {
        reason: input.reason,
        evidenceIds: input.evidenceIds ?? [],
        actor: input.actor,
        changedFields: changed,
      },
    });
    await this.store.append(model);
    return model;
  }

  async close() {
    await this.store.close();
  }
}
