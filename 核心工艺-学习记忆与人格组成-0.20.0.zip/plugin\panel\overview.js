const CATEGORY = {
  read: '阅读与学习',
  expression: '表达与低风险',
  social: '社交与打扰控制',
  public: '公开资料',
  publish: '评价与发布',
  device: '设备与高风险',
};

function h(tag, cls, text) {
  const el = document.createElement(tag);
  if (cls) el.className = cls;
  if (text !== undefined) el.textContent = text;
  return el;
}

function fmtWindow(w) {
  return w ? `${w.start}–${w.end}` : '不限';
}

function fmtLimit(n) {
  return n === null || n === undefined ? '—' : n === 0 ? '不限' : String(n);
}

function fmtCooldown(n) {
  return n === null || n === undefined ? '—' : n === 0 ? '无' : `${n} 分钟`;
}

function normalize(data) {
  if (data?.snapshot) return data.snapshot;
  if (data?.features) return data;
  return null;
}

function card(feature) {
  const el = h('article', feature.enabled ? 'card' : 'card off');
  const head = h('div', 'card-head');
  head.append(h('h3', '', feature.label));
  const pill = h('span', feature.enabled ? 'pill on' : 'pill off', feature.enabled ? '已开启' : '已关闭');
  head.append(pill);
  el.append(head);
  el.append(h('p', 'desc', feature.description || ''));

  const metrics = h('div', 'metrics');
  const add = (label, value) => {
    const box = h('div', 'metric');
    box.append(h('span', '', label));
    box.append(h('strong', '', value));
    metrics.append(box);
  };

  if (feature.limited) {
    add('时间窗', fmtWindow(feature.window));
    add('冷却', fmtCooldown(feature.cooldownMin));
    add('每日上限', fmtLimit(feature.dailyLimit));
    add('每周上限', fmtLimit(feature.weeklyLimit));
  } else {
    add('时间窗', '不限');
    add('频率限制', '无');
    add('硬性等级', `L${feature.hardLevel}`);
    add('类型', feature.category || '—');
  }
  el.append(metrics);

  if (feature.enabled && feature.limited && feature.dailyLimit === 0 && feature.weeklyLimit === 0) {
    el.append(h('p', 'warn', '当前为不限次数；发布/评价类建议设置上限。'));
  }
  if (feature.enabled && feature.hardLevel > 2) {
    el.append(h('p', 'warn', `硬性等级 L${feature.hardLevel}，需要最高权限至少 L${feature.hardLevel} 才会实际放行。`));
  }
  return el;
}

function render(snapshot) {
  document.querySelector('#level').textContent = snapshot.permissionLabel || `L${snapshot.permissionLevel}`;
  const descriptions = {
    0: '只读：不主动社交、不发布。',
    1: '低风险：表情、音乐、学习阅读。',
    2: '社交：私聊、群内接话，受时间窗和频率限制。',
    3: '公共表达：评论、空间、头像，默认关闭。',
    4: '高影响：视频、桌面，默认关闭。',
  };
  document.querySelector('#levelDesc').textContent = descriptions[snapshot.permissionLevel] || '';
  document.querySelector('#timezone').textContent = snapshot.timeZone || '—';
  document.querySelector('#enabled').textContent = snapshot.enabled === false ? '已关闭' : '运行中';
  document.querySelector('#updated').textContent = snapshot.updatedAt
    ? new Date(snapshot.updatedAt).toLocaleString()
    : '示例快照';

  const groups = document.querySelector('#groups');
  groups.replaceChildren();
  const order = ['social', 'publish', 'public', 'expression', 'read', 'device'];
  for (const key of order) {
    const items = (snapshot.features || []).filter((f) => f.category === key);
    if (!items.length) continue;
    const section = h('section', 'group');
    section.append(h('h2', '', CATEGORY[key] || key));
    const grid = h('div', 'grid');
    for (const item of items) grid.append(card(item));
    section.append(grid);
    groups.append(section);
  }
  document.querySelector('#state').textContent = '只读快照';
}

async function load() {
  const candidates = ['../@data/storage.json', './storage.example.json'];
  for (const url of candidates) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) continue;
      const snapshot = normalize(await res.json());
      if (snapshot) {
        render(snapshot);
        return;
      }
    } catch {
      // Try the next source; the panel stays readable when storage is absent.
    }
  }
  document.querySelector('#state').textContent = '无快照';
  document.querySelector('#groups').append(h('p', 'notice', '尚未接入运行快照。启用插件并保存设置后，这里会显示当前权限与限制。'));
}

load();
