﻿# Phase 25 报告：公开版准备

日期：2026-10-27  
状态：公开版文档、协议、导出脚本、发布检查完成；维护者信息待填写。

## 1. 新增运行行为

```text
after-response 记录 dialogue event
```

本地：

```text
events.jsonl
```

不上传。  
记录的是触发文本 + 回复，供未来检索/反思。

仍然不会自动：

```text
生成 Cognition
更新 SelfModel
```

## 2. 公开数据

脚本：

```text
scripts/public-data-export.mjs
```

必须：

```text
--consent public-data-v1
```

输出：

```text
计数
分类
版本
日期
```

不输出：

```text
正文
QQ
昵称
群号
路径
Cookie
SelfModel 文本
```

k=5 抑制。

## 3. 文档

```text
docs/核心架构.md
docs/数据收集协议.md
docs/CONSENT.zh-CN.md
docs/炸机说明（必看！！！！）.md
docs/炸机说明（必看！！！！）.md
docs/PUBLIC_RELEASE.zh-CN.md
docs/public-data.schema.json
```

## 4. 清理

```text
owner-identity disabled
sticker__send_sticker disabled
qzone__publish_qzone_post disabled
persona cleared
```

保留：

```text
speaker-identity
context-chime
sticker 库
qzone 选题/配图/评论
meme-taste（已修 system 改写）
```

## 5. 测试

```text
tests 60
pass 60
fail 0
```

## 6. 发布前必须做

```text
1. 填 DATA_COLLECTION 的维护者/邮箱/项目地址
2. 填 CONSENT 的维护者信息
3. 跑 scan-release
4. 构建 zip
5. 确认 zip 不含 data/
```

## 7. 已存在但未发布

```text
dist/public-data.example.json
```

这是本机聚合示例，不应默认放进发布包。  
如果维护者要公开示例，需要先确认没有小样本可推断问题。


