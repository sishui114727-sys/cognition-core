export const SCHEMA_VERSION = 1;

export class SchemaError extends Error {
  constructor(message, path = '') {
    super(path ? `${path}: ${message}` : message);
    this.name = 'SchemaError';
    this.path = path;
  }
}

const SOURCE_TYPES = new Set([
  'chat', 'bili', 'web', 'document', 'book', 'action', 'admin',
  'legacy-mem-layered', 'legacy-cross-memory', 'legacy-life-memory',
  'legacy-impression', 'dialogue',
]);
const PRIVACY = new Set(['private', 'relationship', 'group', 'public']);
const SCOPE_KINDS = new Set(['global', 'person', 'group', 'relationship']);

export function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function fail(message, path = '') {
  throw new SchemaError(message, path);
}

function requireString(value, path, { min = 1, max = 200000 } = {}) {
  if (typeof value !== 'string') fail('must be a string', path);
  if (value.length < min) fail(`must be at least ${min} chars`, path);
  if (value.length > max) fail(`must be at most ${max} chars`, path);
  return value;
}

function optionalString(value, path, max = 200000) {
  if (value === undefined || value === null) return undefined;
  return requireString(value, path, { min: 0, max });
}

function timestamp(value, path) {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) fail('must be a finite timestamp', path);
    const d = new Date(value < 1e12 ? value * 1000 : value);
    if (Number.isNaN(d.getTime())) fail('invalid timestamp', path);
    return d.toISOString();
  }
  if (typeof value === 'string') {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) fail('invalid ISO timestamp', path);
    return d.toISOString();
  }
  fail('must be ISO string or epoch milliseconds', path);
}

function score(value, path, fallback) {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1) {
    fail('must be a number in [0,1]', path);
  }
  return value;
}

export function normalizeScope(value, path = 'scope') {
  if (typeof value === 'string') {
    if (value === 'global') return Object.freeze({ kind: 'global', id: null });
    const m = /^(person|group|relationship):(.+)$/.exec(value);
    if (!m) fail('scope string must be global, person:<id>, group:<id> or relationship:<id>', path);
    return Object.freeze({ kind: m[1], id: m[2] });
  }
  if (!isPlainObject(value)) fail('must be object or scope string', path);
  if (!SCOPE_KINDS.has(value.kind)) fail(`unknown scope kind: ${value.kind}`, `${path}.kind`);
  if (value.kind === 'global') return Object.freeze({ kind: 'global', id: null });
  const id = requireString(value.id, `${path}.id`, { min: 1, max: 256 });
  return Object.freeze({ kind: value.kind, id });
}

export function validateIdentityAnchor(value) {
  if (!isPlainObject(value)) fail('must be an object', 'identity');
  const allowed = new Set(['adminId', 'displayName', 'relation', 'permissions', 'hardBoundaries', 'metadata']);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`unknown identity field: ${key}`, 'identity');
  }
  const adminId = requireString(value.adminId, 'identity.adminId', { max: 128 });
  const permissions = Array.isArray(value.permissions) ? value.permissions.map((x) => requireString(x, 'identity.permissions[]', { max: 128 })) : [];
  const hardBoundaries = Array.isArray(value.hardBoundaries) ? value.hardBoundaries.map((x) => requireString(x, 'identity.hardBoundaries[]', { max: 512 })) : [];
  return Object.freeze({
    adminId,
    displayName: optionalString(value.displayName, 'identity.displayName', 128),
    relation: optionalString(value.relation, 'identity.relation', 128),
    permissions: Object.freeze(permissions),
    hardBoundaries: Object.freeze(hardBoundaries),
    metadata: value.metadata && isPlainObject(value.metadata) ? Object.freeze({ ...value.metadata }) : Object.freeze({}),
  });
}

export function validatePerson(value) {
  if (!isPlainObject(value)) fail('must be an object', 'person');
  const allowed = new Set(['id', 'platform', 'displayName', 'isOwner', 'metadata']);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`unknown person field: ${key}`, 'person');
  }
  return Object.freeze({
    id: requireString(value.id, 'person.id', { max: 128 }),
    platform: requireString(value.platform, 'person.platform', { max: 32 }),
    displayName: optionalString(value.displayName, 'person.displayName', 128),
    isOwner: value.isOwner === true,
    metadata: value.metadata && isPlainObject(value.metadata) ? Object.freeze({ ...value.metadata }) : Object.freeze({}),
  });
}

export function validateRelationship(value) {
  if (!isPlainObject(value)) fail('must be an object', 'relationship');
  const allowed = new Set(['id', 'personId', 'role', 'trust', 'permissions', 'boundaries', 'metadata']);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`unknown relationship field: ${key}`, 'relationship');
  }
  const permissions = Array.isArray(value.permissions) ? value.permissions.map((x) => requireString(x, 'relationship.permissions[]', { max: 128 })) : [];
  const boundaries = Array.isArray(value.boundaries) ? value.boundaries.map((x) => requireString(x, 'relationship.boundaries[]', { max: 512 })) : [];
  return Object.freeze({
    id: requireString(value.id, 'relationship.id', { max: 128 }),
    personId: requireString(value.personId, 'relationship.personId', { max: 128 }),
    role: requireString(value.role, 'relationship.role', { max: 64 }),
    trust: score(value.trust, 'relationship.trust', 0.5),
    permissions: Object.freeze(permissions),
    boundaries: Object.freeze(boundaries),
    metadata: value.metadata && isPlainObject(value.metadata) ? Object.freeze({ ...value.metadata }) : Object.freeze({}),
  });
}

function stringArray(value, path, max = 2000) {
  if (value === undefined || value === null) return Object.freeze([]);
  if (!Array.isArray(value)) fail('must be an array', path);
  return Object.freeze(value.map((x) => requireString(x, path, { max })));
}

export function validateEpisode(value) {
  if (!isPlainObject(value)) fail('must be an object', 'episode');
  const allowed = new Set(['schemaVersion', 'id', 'start', 'end', 'scope', 'eventIds', 'title', 'situation', 'understanding', 'choice', 'outcome', 'confidence', 'privacy', 'metadata']);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`unknown episode field: ${key}`, 'episode');
  }
  const scope = normalizeScope(value.scope, 'episode.scope');
  const privacy = value.privacy ?? (scope.kind === 'group' ? 'group' : scope.kind === 'global' ? 'public' : 'private');
  if (!PRIVACY.has(privacy)) fail(`unknown privacy: ${privacy}`, 'episode.privacy');
  const start = timestamp(value.start, 'episode.start');
  const end = timestamp(value.end, 'episode.end');
  if (Date.parse(end) < Date.parse(start)) fail('end must be >= start', 'episode.end');
  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    id: requireString(value.id, 'episode.id', { max: 256 }),
    start,
    end,
    scope,
    eventIds: stringArray(value.eventIds, 'episode.eventIds', 256),
    title: requireString(value.title, 'episode.title', { max: 500 }),
    situation: requireString(value.situation, 'episode.situation', { max: 20000 }),
    understanding: optionalString(value.understanding, 'episode.understanding', 20000),
    choice: optionalString(value.choice, 'episode.choice', 20000),
    outcome: optionalString(value.outcome, 'episode.outcome', 20000),
    confidence: score(value.confidence, 'episode.confidence', 0.5),
    privacy,
    metadata: value.metadata && isPlainObject(value.metadata) ? Object.freeze({ ...value.metadata }) : Object.freeze({}),
  });
}

const COGNITION_KINDS = new Set(['fact', 'preference', 'value', 'commitment', 'boundary', 'hypothesis']);
const COGNITION_STATUS = new Set(['candidate', 'stable', 'contested', 'retired']);

export function validateCognition(value) {
  if (!isPlainObject(value)) fail('must be an object', 'cognition');
  const allowed = new Set(['schemaVersion', 'id', 'scope', 'kind', 'subject', 'relation', 'object', 'statement', 'evidenceEventIds', 'evidenceEpisodeIds', 'confidence', 'contradictions', 'status', 'firstSeen', 'lastConfirmed', 'createdAt', 'updatedAt', 'revision', 'changeReason', 'metadata']);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`unknown cognition field: ${key}`, 'cognition');
  }
  if (!COGNITION_KINDS.has(value.kind)) fail(`unknown cognition kind: ${value.kind}`, 'cognition.kind');
  if (!COGNITION_STATUS.has(value.status)) fail(`unknown cognition status: ${value.status}`, 'cognition.status');
  const revision = Number(value.revision);
  if (!Number.isInteger(revision) || revision < 1) fail('revision must be a positive integer', 'cognition.revision');
  const evidenceEventIds = stringArray(value.evidenceEventIds, 'cognition.evidenceEventIds', 256);
  const evidenceEpisodeIds = stringArray(value.evidenceEpisodeIds, 'cognition.evidenceEpisodeIds', 256);
  if (value.status === 'stable' && evidenceEventIds.length + evidenceEpisodeIds.length === 0) {
    fail('stable cognition requires at least one evidence reference', 'cognition.evidence');
  }
  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    id: requireString(value.id, 'cognition.id', { max: 256 }),
    scope: normalizeScope(value.scope, 'cognition.scope'),
    kind: value.kind,
    subject: optionalString(value.subject, 'cognition.subject', 500),
    relation: optionalString(value.relation, 'cognition.relation', 500),
    object: optionalString(value.object, 'cognition.object', 2000),
    statement: requireString(value.statement, 'cognition.statement', { max: 5000 }),
    evidenceEventIds,
    evidenceEpisodeIds,
    confidence: score(value.confidence, 'cognition.confidence', 0.5),
    contradictions: stringArray(value.contradictions, 'cognition.contradictions', 1000),
    status: value.status,
    firstSeen: timestamp(value.firstSeen, 'cognition.firstSeen'),
    lastConfirmed: timestamp(value.lastConfirmed, 'cognition.lastConfirmed'),
    createdAt: timestamp(value.createdAt, 'cognition.createdAt'),
    updatedAt: timestamp(value.updatedAt, 'cognition.updatedAt'),
    revision,
    changeReason: optionalString(value.changeReason, 'cognition.changeReason', 2000),
    metadata: value.metadata && isPlainObject(value.metadata) ? Object.freeze({ ...value.metadata }) : Object.freeze({}),
  });
}

export function validateSelfModel(value) {
  if (!isPlainObject(value)) fail('must be an object', 'selfModel');
  const allowed = new Set(['schemaVersion', 'version', 'values', 'commitments', 'boundaries', 'openQuestions', 'selfNarrative', 'updatedAt', 'change']);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`unknown selfModel field: ${key}`, 'selfModel');
  }
  const version = Number(value.version);
  if (!Number.isInteger(version) || version < 1) fail('version must be a positive integer', 'selfModel.version');
  if (!isPlainObject(value.change)) fail('must be an object', 'selfModel.change');
  const change = value.change;
  const changeAllowed = new Set(['reason', 'evidenceIds', 'actor', 'changedFields']);
  for (const key of Object.keys(change)) {
    if (!changeAllowed.has(key)) fail(`unknown change field: ${key}`, 'selfModel.change');
  }
  if (!change.reason) fail('change.reason is required', 'selfModel.change.reason');
  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    version,
    values: stringArray(value.values, 'selfModel.values'),
    commitments: stringArray(value.commitments, 'selfModel.commitments'),
    boundaries: stringArray(value.boundaries, 'selfModel.boundaries'),
    openQuestions: stringArray(value.openQuestions, 'selfModel.openQuestions'),
    selfNarrative: optionalString(value.selfNarrative, 'selfModel.selfNarrative', 20000),
    updatedAt: timestamp(value.updatedAt, 'selfModel.updatedAt'),
    change: Object.freeze({
      reason: requireString(change.reason, 'selfModel.change.reason', { max: 2000 }),
      evidenceIds: stringArray(change.evidenceIds, 'selfModel.change.evidenceIds', 256),
      actor: optionalString(change.actor, 'selfModel.change.actor', 128),
      changedFields: stringArray(change.changedFields, 'selfModel.change.changedFields', 128),
    }),
  });
}

export function normalizeEvent(value) {
  if (!isPlainObject(value)) fail('must be an object', 'event');
  const scope = normalizeScope(value.scope, 'event.scope');
  if (!isPlainObject(value.source)) fail('must be an object', 'event.source');
  const sourceType = requireString(value.source.type, 'event.source.type', { max: 64 });
  if (!SOURCE_TYPES.has(sourceType)) fail(`unknown source type: ${sourceType}`, 'event.source.type');
  const source = Object.freeze({
    type: sourceType,
    id: requireString(value.source.id, 'event.source.id', { max: 256 }),
    ref: requireString(value.source.ref, 'event.source.ref', { max: 2000 }),
  });

  if (!Array.isArray(value.participants)) fail('must be an array', 'event.participants');
  const participants = value.participants.map((p, i) => {
    if (!isPlainObject(p)) fail('must be an object', `event.participants[${i}]`);
    return Object.freeze({
      id: requireString(p.id, `event.participants[${i}].id`, { max: 128 }),
      role: optionalString(p.role, `event.participants[${i}].role`, 64),
    });
  });

  const privacy = value.privacy ?? (scope.kind === 'group' ? 'group' : scope.kind === 'global' ? 'public' : 'private');
  if (!PRIVACY.has(privacy)) fail(`unknown privacy: ${privacy}`, 'event.privacy');

  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    id: requireString(value.id, 'event.id', { max: 256 }),
    time: timestamp(value.time, 'event.time'),
    scope,
    source,
    participants: Object.freeze(participants),
    text: requireString(value.text, 'event.text', { max: 200000 }),
    summary: optionalString(value.summary, 'event.summary', 20000),
    confidence: score(value.confidence, 'event.confidence', 0.5),
    salience: score(value.salience, 'event.salience', 0.5),
    privacy,
    metadata: value.metadata && isPlainObject(value.metadata) ? Object.freeze({ ...value.metadata }) : Object.freeze({}),
  });
}
