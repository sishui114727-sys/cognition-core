export const DEFAULT_PROMOTION_POLICY = Object.freeze({
  minEvidence: 2,
  minConfidence: 0.7,
  blockOnContradictions: true,
});

export function evaluatePromotion(cognition, policy = {}) {
  const rules = { ...DEFAULT_PROMOTION_POLICY, ...policy };
  const reasons = [];
  if (cognition.status !== 'candidate') reasons.push('not-candidate');
  const evidenceCount = (cognition.evidenceEventIds?.length ?? 0) + (cognition.evidenceEpisodeIds?.length ?? 0);
  if (evidenceCount < rules.minEvidence) reasons.push(`evidence<${rules.minEvidence}`);
  if (cognition.confidence < rules.minConfidence) reasons.push(`confidence<${rules.minConfidence}`);
  if (rules.blockOnContradictions && cognition.contradictions.length > 0) reasons.push('has-contradictions');
  return { promote: reasons.length === 0, reasons, evidenceCount };
}

export function withPromotion(cognition, policy = {}) {
  const result = evaluatePromotion(cognition, policy);
  if (!result.promote) return { cognition, result };
  return {
    result,
    cognition: {
      ...cognition,
      status: 'stable',
      revision: cognition.revision + 1,
      lastConfirmed: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      changeReason: `promotion: ${result.evidenceCount} evidence, confidence=${cognition.confidence}`,
    },
  };
}
