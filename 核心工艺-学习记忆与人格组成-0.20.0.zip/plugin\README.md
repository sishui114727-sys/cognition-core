# cognition-core

社区版认知核心。

可以作为 QQA 插件安装，但还不替代旧记忆插件，也不自动注入人格。  
它提供**认知与自我模型的地基**，通过只读工具和受控 ActionBus 暴露能力。

## 当前阶段

```text
Phase 1  事件地基       完成
Phase 2  认知与自我模型 完成
Phase 3  行动总线       完成
Phase 4  低风险 Adapter 完成（mock + sticker）
Phase 5  更多 Adapter   完成（music + private chat + mock host）
Phase 6  文档与 token  完成（使用说明、兼容性、ContextPack）
Phase 7  权限与 GUI    完成（权限等级、功能开关、时间窗、日/周限额、只读面板）
Phase 8  QQA host      完成（setup/activate、settings→Gateway、snapshot→storage、只读工具）
Phase 9  记忆迁移      完成（3764 条冻结事件导入，旧三套记忆引擎停写）
Phase 10 顶栏与注入    完成（顶栏「认知」、ContextPack 默认关闭、49 项测试）
Phase 11 检索评估      完成（200 样本 lexical proxy；600 token 为默认预算）
Phase 12 A/B           完成（基线 vs 600 token 注入；+305 token/轮，缓存无明显崩塌；注入已关闭）
Phase 13 认人迁移      完成（21 人 / 21 关系 / 67 印象；新认人卡片已在群聊验证）
Phase 14 真实 sticker  完成（owner-only 真实发送已验收；admin 变更需重载）
Phase 15 旧工具收口    完成（memory_append/query/remove 已禁用）
Phase 16 人设卡移除    完成（persona / per-chat / customPersonas 全部清空并验证）
Phase 17 Owner/SelfModel 完成（owner 关系入库；SelfModel v1；未注入）
Phase 18 超时修复    完成（person-cards 索引；cognition_self 只读工具）
Phase 19 真实私聊    完成（owner-only 真实发送已验收）
Phase 20 SelfModel   完成（只读工具；不自动注入）
Phase 21 B站只读    完成（搜索/视频信息；真实 API + QQ action log 通过）
Phase 22 小黑盒只读  完成（信息流真实 API + QQ action log 通过）
Phase 23 QQ空间只读  完成（真实 QQ action log 通过）
Phase 24 QQ空间发布  完成（core Adapter 真实发布成功；旧发布工具已关闭）
Phase 25 公开版      完成（0.20.0 公开包；协议/导出/扫描/核心/风险/冲突文档）
Phase 26 表情额度    完成（默认无限制；stickerDailyLimit 可配置）
```

```text
QQA 已安装 cognition-core 0.20.0
adminId 已绑定，真实表情发送已通过
owner 关系已入库；SelfModel v1 只读检索，未注入
真实私聊工具已注册，待测试
旧 mem-layered / cross-memory / life-memory 已停写
cross-chat-link 保留
3764 条冻结事件已导入 QQA core
只读工具：cognition_status / cognition_recall
顶栏已增加「认知」入口
社区包：cognition-core-community-0.8.0.zip
无自动注入；不增加常驻 token
未接真实 QQ/B站/小黑盒/QQ空间 Adapter
```

## 文档

- [使用说明](docs/USER_GUIDE.zh-CN.md)
- [兼容性说明](docs/COMPATIBILITY.zh-CN.md)
- [Token 预算与优化](docs/TOKEN_BUDGET.zh-CN.md)
- [权限 GUI 说明](docs/GUI.zh-CN.md)
- [QQA 顶栏模块](docs/QQA_TOPBAR.zh-CN.md)

## 数据模型

```text
IdentityAnchor
Person
Relationship
Event            只追加
Episode          只追加
Cognition        只追加修订，最新版本物化
SelfModel        只追加版本，每个版本带 change
```

### Event

```text
id, time, scope, source {type,id,ref}, participants,
text, summary, confidence, salience, privacy, metadata
```

每条 Event 必须有 `source.ref`，保证可回到原文。

### Cognition

```text
id, scope, kind, subject, relation, object, statement,
evidenceEventIds, evidenceEpisodeIds,
confidence, contradictions,
status: candidate / stable / contested / retired,
revision, changeReason
```

- `stable` 必须至少有一条证据
- 更新不覆盖旧版本，只追加 `revision + 1`
- `history(id)` 可回看完整修订

### SelfModel

```text
version
values
commitments
boundaries
openQuestions
selfNarrative
updatedAt
change { reason, evidenceIds, actor, changedFields }
```

- 每个版本都是 append-only
- 不静默覆盖
- 每个版本必须写 `change.reason`
- `changedFields` 由前后版本自动计算

## 命令

```bash
node --test

node scripts/import-legacy.mjs --source-root "<QQA data dir>"           # dry-run
node scripts/import-legacy.mjs --source-root "<QQA data dir>" --write   # 写入 data/events.jsonl
```

也可以设置环境变量 `QQA_DATA_DIR` 代替 `--source-root`。

## 当前导入结果

```text
mem-layered blocks   294
cross-memory        3458
life-events           12
total               3764
```

冻结导入在 QQA 停止后进行。

## 设计约束

- 模块顶层不做 IO
- EventStore / JsonlStore 首次 append 才创建文件
- append 串行
- 读到坏行显式报错，不静默跳过
- IdentityAnchor 不接受 personality 字段
- 每条 Event 必须带 source.ref
- 认知不覆盖，只追加修订
- 自我模型不覆盖，只追加版本
- 不注入提示词，不自动行动，不写人格文件

## 行动总线

```text
ActionBus
  register(capability)
  execute({ action, senderId, confirmed, target, ... })
  action-log.jsonl
```

所有能力默认：

```text
ownerOnly: true
```

另外强制：

- 公共/不可逆动作需要 `confirmed`
- 数据外发（egress）需要 `confirmed`
- 自毁动作需要 `confirmed`
- 非主人一律拒绝
- 拒绝和成功都写审计

`origin: 'self'` 表示认知核心自己发起，不是用户输入。  
宿主调度器才能设置它；用户输入不得设置，否则等于绕过 P2。

## 低风险 Adapter

```text
src/adapters/mock.js        无副作用 mock
src/adapters/sticker.js     本地表情目录选择，不发送
src/adapters/music.js       本地音乐目录选择，不播放
src/adapters/private-chat.js owner-only 私聊端口 + mock transport
src/adapters/mock-host.js   无 QQ/无网络/无桌面的组合宿主
```

StickerAdapter：

- 读取本地 `catalog.json`
- 支持 `stickerId` 或 `tags`
- 校验路径不能逃出 root
- 校验文件存在与大小
- 只返回 payload，不发送到 QQ

MusicAdapter：

- 读取本地 `catalog.json`
- 支持 `trackId` 或 `tags`
- 校验路径不能逃出 root
- 只返回 payload，不播放

PrivateChatAdapter：

- `transport.send` 由宿主注入
- 默认只允许发给 owner
- 只允许 owner / self 发起
- 不接真实 QQ

MockHost：

```js
const host = createMockHost({ dataDir, identity, stickerCatalog, musicCatalog });
```

## 还不做

- 自动从对话归纳 Cognition
- 自动更新 SelfModel
- 真实私聊/表情/B站/QQ
- 桌面控制
- QQA 安装

## 权限 GUI

QQA 设置表单（可编辑）：

```text
最高权限等级 L0–L4
11 个功能接口开关
每个社交/评价/发布功能：
  允许时间窗
  每日条数上限
  每周条数上限
  冷却分钟
```

插件页：

```text
panel/overview.html
```

它是只读总览。  
QQA 的插件页面通道只读，避免页面绕过配置与权限校验；修改仍走设置表单。

## ContextPack 评估

```bash
node scripts/evaluate-context.mjs \
  --data-dir "<QQA core data dir>" \
  --samples 200
```

结果写入 `docs/context-eval.json`，不包含聊天原文。

## A/B 数据

```text
docs/ab-baseline.json
docs/ab-injection.json
docs/phase12-ab-report.md
```

## 公开版文档

```text
docs/核心架构.md
docs/数据收集协议.md
docs/CONSENT.zh-CN.md
docs/炸机说明（必看！！！！）.md
docs/PUBLIC_RELEASE.zh-CN.md
docs/命名规范.md
```

## 下一步

```text
替换维护者/联系方式占位符
跑 node --test
跑 scan-release
构建 0.20.0 公开包
观察无卡表达
SelfModel 检索策略
```



