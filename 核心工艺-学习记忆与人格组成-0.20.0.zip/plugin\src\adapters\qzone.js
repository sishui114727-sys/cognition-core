import { RISK } from '../action-policy.js';

function strip(value) {
  return String(value || '')
    .replace(/<br\s*\/?>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function parseComments(html) {
  const src = String(html || '');
  const marks = [];
  const re = /<li class="comments-item[^"]*"([^>]*)>/g;
  let match;
  while ((match = re.exec(src)) !== null) marks.push({ index: match.index, head: match[1] });
  const out = [];
  for (let i = 0; i < marks.length; i += 1) {
    const chunk = src.slice(marks[i].index, i + 1 < marks.length ? marks[i + 1].index : src.length);
    const get = (key) => new RegExp(`${key}="([^"]*)"`).exec(marks[i].head)?.[1] || '';
    const tid = get('data-tid');
    if (!tid) continue;
    const body = /<div class="comments-content">([\s\S]*?)<div class="comments-op"/.exec(chunk)?.[1] || '';
    out.push({
      tid,
      uin: get('data-uin'),
      nick: get('data-nick'),
      type: get('data-type') || 'commentroot',
      text: strip(body.replace(/<a class="nickname[\s\S]*?<\/a>/i, ' ')).replace(/^[:：]\s*/, ''),
    });
  }
  return out;
}

function postsFromFeeds(feeds) {
  const list = Array.isArray(feeds) ? feeds : (feeds && typeof feeds === 'object' ? [feeds] : []);
  return list.map((feed) => {
    const html = String(feed?.html || '');
    const tid = String(feed?.key || /data-tid="([^"]+)"/.exec(html)?.[1] || '');
    const comments = parseComments(html);
    return {
      tid,
      ownerUin: String(feed?.uin || ''),
      ownerNick: String(feed?.nickname || ''),
      time: Number(feed?.time) || 0,
      text: strip(html).slice(0, 260),
      comments: comments.slice(0, 8).map((comment) => ({
        tid: comment.tid,
        author: comment.nick,
        text: comment.text.slice(0, 220),
        type: comment.type,
      })),
      commentCount: comments.length,
    };
  }).filter((post) => post.tid);
}

export class QzoneReadAdapter {
  async read({ ctx, limit = 5 }) {
    if (!ctx?.onebot || typeof ctx.onebot.call !== 'function') {
      throw new Error('OneBot Qzone reader is unavailable');
    }
    const n = Math.max(1, Math.min(10, Number(limit) || 5));
    const feeds = await ctx.onebot.call('get_qzone_feeds', { page_num: 1, count: n });
    const selfId = String(ctx.selfId || '');
    const posts = postsFromFeeds(feeds?.feeds ?? feeds)
      .filter((post) => !selfId || post.ownerUin === selfId);
    return { posts: posts.slice(0, n) };
  }

  register(bus) {
    bus.register({
      name: 'qzone.read',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'qzoneRead',
      execute: ({ ctx, limit }) => this.read({ ctx, limit }),
    });
    return bus;
  }
}
