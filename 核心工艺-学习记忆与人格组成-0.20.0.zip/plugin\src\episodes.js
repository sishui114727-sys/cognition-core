import { randomUUID } from 'node:crypto';
import { JsonlStore } from './jsonl.js';
import { validateEpisode } from './schema.js';

export class EpisodeStore {
  constructor({ dataDir }) {
    this.store = new JsonlStore({ dataDir, fileName: 'episodes.jsonl' });
    this.dataDir = dataDir;
  }

  append(input) {
    const episode = validateEpisode({
      ...input,
      schemaVersion: 1,
      id: input.id ?? `ep_${randomUUID()}`,
    });
    return this.store.append(episode);
  }

  async list({ scope, limit = 100 } = {}) {
    const rows = await this.store.readAll();
    return rows
      .filter((row) => !scope || (row.scope.kind === scope.kind && row.scope.id === scope.id))
      .sort((a, b) => Date.parse(b.end) - Date.parse(a.end))
      .slice(0, Math.max(0, limit));
  }

  async get(id) {
    const rows = await this.store.readAll();
    return rows.find((row) => row.id === id) ?? null;
  }

  async close() {
    await this.store.close();
  }
}
