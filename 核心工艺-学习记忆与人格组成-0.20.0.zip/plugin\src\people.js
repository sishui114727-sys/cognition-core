import { JsonlStore } from './jsonl.js';
import { validatePerson, validateRelationship } from './schema.js';

function latestById(rows) {
  const map = new Map();
  for (const row of rows) map.set(row.id, row);
  return map;
}

export class PersonStore {
  constructor({ dataDir }) {
    this.store = new JsonlStore({ dataDir, fileName: 'persons.jsonl' });
    this.dataDir = dataDir;
  }

  async append(input) {
    const person = validatePerson(input);
    const rows = await this.store.readAll();
    const existing = latestById(rows).get(person.id);
    if (existing) return existing;
    await this.store.append(person);
    return person;
  }

  async upsert(input) {
    const person = validatePerson(input);
    await this.store.append(person);
    return person;
  }

  async get(id) {
    const rows = await this.store.readAll();
    return latestById(rows).get(id) ?? null;
  }

  async list() {
    return [...latestById(await this.store.readAll()).values()];
  }

  async close() {
    await this.store.close();
  }
}

export class RelationshipStore {
  constructor({ dataDir }) {
    this.store = new JsonlStore({ dataDir, fileName: 'relationships.jsonl' });
    this.dataDir = dataDir;
  }

  async append(input) {
    const relationship = validateRelationship(input);
    const rows = await this.store.readAll();
    const existing = latestById(rows).get(relationship.id);
    if (existing) return existing;
    await this.store.append(relationship);
    return relationship;
  }

  async upsert(input) {
    const relationship = validateRelationship(input);
    await this.store.append(relationship);
    return relationship;
  }

  async get(id) {
    const rows = await this.store.readAll();
    return latestById(rows).get(id) ?? null;
  }

  async list() {
    return [...latestById(await this.store.readAll()).values()];
  }

  async close() {
    await this.store.close();
  }
}
