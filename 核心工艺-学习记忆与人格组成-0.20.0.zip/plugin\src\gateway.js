import { normalizePolicy, permissionLabel, FEATURE_MAP } from './gateway-policy.js';
import { UsageLedger } from './usage-ledger.js';

export class Gateway {
  constructor({ policy, dataDir }) {
    this.policy = normalizePolicy(policy);
    this.usage = new UsageLedger({ dataDir, timeZone: this.policy.timeZone });
  }

  async check({ feature, at = new Date() }) {
    if (!this.policy.enabled) return { allowed: false, reason: 'gateway-disabled' };
    const meta = FEATURE_MAP.get(feature);
    if (!meta) return { allowed: false, reason: 'unknown-feature' };
    if (meta.level > this.policy.permissionLevel) {
      return {
        allowed: false,
        reason: 'permission-level',
        requiredLevel: meta.level,
        currentLevel: this.policy.permissionLevel,
      };
    }
    return this.usage.check({ feature, policy: this.policy, at });
  }

  async record({ feature, action, actor, at = new Date() }) {
    return this.usage.record({ feature, action, actor, at });
  }

  snapshot() {
    return {
      updatedAt: new Date().toISOString(),
      permissionLevel: this.policy.permissionLevel,
      permissionLabel: permissionLabel(this.policy.permissionLevel),
      timeZone: this.policy.timeZone,
      features: Object.fromEntries(Object.entries(this.policy.features).map(([key, value]) => [
        key,
        {
          ...value,
          label: FEATURE_MAP.get(key)?.label ?? key,
          category: FEATURE_MAP.get(key)?.category ?? 'unknown',
          hardLevel: FEATURE_MAP.get(key)?.level ?? 4,
          limited: Boolean(FEATURE_MAP.get(key)?.limited),
        },
      ])),
    };
  }

  async close() {
    await this.usage.close();
  }
}
