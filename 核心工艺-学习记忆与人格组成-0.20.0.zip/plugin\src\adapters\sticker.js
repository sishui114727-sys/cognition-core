import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { RISK } from '../action-policy.js';

export class StickerNotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = 'StickerNotFoundError';
  }
}

export class StickerAdapter {
  constructor({ catalogFile, rootDir, maxBytes = 8 * 1024 * 1024 }) {
    if (!catalogFile) throw new Error('catalogFile is required');
    this.catalogFile = path.resolve(catalogFile);
    this.rootDir = path.resolve(rootDir ?? path.dirname(this.catalogFile));
    this.maxBytes = maxBytes;
    this._catalog = null;
  }

  async loadCatalog() {
    if (this._catalog) return this._catalog;
    const data = JSON.parse(await readFile(this.catalogFile, 'utf8'));
    if (!Array.isArray(data?.stickers)) throw new Error('catalog.stickers must be an array');
    const seen = new Set();
    const stickers = data.stickers.map((entry, i) => {
      if (!entry?.id || !entry?.file) throw new Error(`catalog.stickers[${i}] needs id/file`);
      if (seen.has(entry.id)) throw new Error(`duplicate sticker id: ${entry.id}`);
      seen.add(entry.id);
      return Object.freeze({
        id: String(entry.id),
        file: String(entry.file),
        mime: String(entry.mime ?? 'image/png'),
        tags: Object.freeze(Array.isArray(entry.tags) ? entry.tags.map(String) : []),
        caption: entry.caption ? String(entry.caption) : undefined,
      });
    });
    this._catalog = Object.freeze({ stickers: Object.freeze(stickers) });
    return this._catalog;
  }

  resolvePath(entry) {
    const resolved = path.resolve(this.rootDir, entry.file);
    const root = this.rootDir.endsWith(path.sep) ? this.rootDir : `${this.rootDir}${path.sep}`;
    if (resolved !== this.rootDir && !resolved.startsWith(root)) {
      throw new Error(`sticker path escapes root: ${entry.file}`);
    }
    return resolved;
  }

  async select({ stickerId, tags = [] } = {}) {
    const catalog = await this.loadCatalog();
    let chosen;
    if (stickerId) {
      chosen = catalog.stickers.find((entry) => entry.id === stickerId);
    } else {
      const wanted = new Set(tags);
      chosen = catalog.stickers
        .map((entry) => ({ entry, score: entry.tags.filter((tag) => wanted.has(tag)).length }))
        .filter((row) => row.score > 0)
        .sort((a, b) => b.score - a.score)[0]?.entry;
    }
    if (!chosen) throw new StickerNotFoundError('no matching sticker');
    const file = this.resolvePath(chosen);
    const info = await stat(file);
    if (!info.isFile()) throw new Error(`sticker is not a file: ${chosen.id}`);
    if (info.size > this.maxBytes) throw new Error(`sticker too large: ${chosen.id}`);
    return {
      kind: 'sticker',
      id: chosen.id,
      path: file,
      mime: chosen.mime,
      caption: chosen.caption,
    };
  }

  register(bus) {
    bus.register({
      name: 'sticker.send',
      risk: RISK.LOW,
      ownerOnly: true,
      feature: 'sticker',
      execute: async ({ stickerId, tags }) => this.select({ stickerId, tags }),
    });
    return bus;
  }
}
