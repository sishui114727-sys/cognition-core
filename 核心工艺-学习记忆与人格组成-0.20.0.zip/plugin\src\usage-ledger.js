import { JsonlStore } from './jsonl.js';

function asDate(value) {
  const d = value instanceof Date ? value : new Date(value ?? Date.now());
  if (Number.isNaN(d.getTime())) throw new Error('invalid usage timestamp');
  return d;
}

function partsInZone(date, timeZone) {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });
  const out = {};
  for (const part of fmt.formatToParts(date)) {
    if (part.type !== 'literal') out[part.type] = part.value;
  }
  return out;
}

export function dateKey(date, timeZone) {
  const p = partsInZone(asDate(date), timeZone);
  return `${p.year}-${p.month}-${p.day}`;
}

export function weekKey(date, timeZone) {
  const p = partsInZone(asDate(date), timeZone);
  const target = new Date(Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day)));
  const dayNr = (target.getUTCDay() + 6) % 7;
  target.setUTCDate(target.getUTCDate() - dayNr + 3);
  const firstThursday = new Date(Date.UTC(target.getUTCFullYear(), 0, 4));
  const firstDayNr = (firstThursday.getUTCDay() + 6) % 7;
  firstThursday.setUTCDate(firstThursday.getUTCDate() - firstDayNr + 3);
  const week = 1 + Math.round((target - firstThursday) / (7 * 86400000));
  return `${target.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}

export function minuteOfDay(date, timeZone) {
  const p = partsInZone(asDate(date), timeZone);
  return Number(p.hour) * 60 + Number(p.minute);
}

export function withinWindow(date, window, timeZone) {
  if (!window) return true;
  const start = Number(window.start.split(':')[0]) * 60 + Number(window.start.split(':')[1]);
  const end = Number(window.end.split(':')[0]) * 60 + Number(window.end.split(':')[1]);
  if (start === end) return true;
  const now = minuteOfDay(date, timeZone);
  return start < end ? now >= start && now < end : now >= start || now < end;
}

export class UsageLedger {
  constructor({ dataDir, timeZone = 'Asia/Hong_Kong' }) {
    this.timeZone = timeZone;
    this.store = new JsonlStore({ dataDir, fileName: 'usage.jsonl' });
  }

  async record({ feature, action, actor, at = new Date() }) {
    const row = {
      at: asDate(at).toISOString(),
      feature: String(feature),
      action: String(action),
      actor: String(actor ?? 'self'),
    };
    await this.store.append(row);
    return row;
  }

  async check({ feature, policy, at = new Date() }) {
    const f = policy?.features?.[feature];
    if (!f) return { allowed: false, reason: 'unknown-feature', counts: {} };
    if (!f.enabled) return { allowed: false, reason: 'feature-disabled', counts: {} };
    const now = asDate(at);
    if (f.window && !withinWindow(now, f.window, this.timeZone)) {
      return { allowed: false, reason: 'outside-time-window', counts: {} };
    }
    const rows = (await this.store.readAll()).filter((row) => row.feature === feature);
    const day = dateKey(now, this.timeZone);
    const week = weekKey(now, this.timeZone);
    const dayCount = rows.filter((row) => dateKey(row.at, this.timeZone) === day).length;
    const weekCount = rows.filter((row) => weekKey(row.at, this.timeZone) === week).length;
    if (f.dailyLimit > 0 && dayCount >= f.dailyLimit) {
      return { allowed: false, reason: 'daily-limit', counts: { dayCount, weekCount } };
    }
    if (f.weeklyLimit > 0 && weekCount >= f.weeklyLimit) {
      return { allowed: false, reason: 'weekly-limit', counts: { dayCount, weekCount } };
    }
    if (f.cooldownMin > 0 && rows.length > 0) {
      const last = Math.max(...rows.map((row) => Date.parse(row.at)));
      if (now.getTime() - last < f.cooldownMin * 60000) {
        return { allowed: false, reason: 'cooldown', counts: { dayCount, weekCount } };
      }
    }
    return { allowed: true, reason: 'allowed', counts: { dayCount, weekCount } };
  }

  async close() {
    await this.store.close();
  }
}
