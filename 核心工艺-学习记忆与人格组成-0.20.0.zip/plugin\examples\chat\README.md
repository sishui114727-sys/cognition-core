# Private Chat Example

```js
import { ActionBus, PrivateChatAdapter, MockChatTransport } from 'cognition-core';

const transport = new MockChatTransport();
const bus = new ActionBus({ dataDir, identity });
new PrivateChatAdapter({
  transport,
  ownerId: identity.adminId,
  allowedTargets: [], // owner only by default
}).register(bus);

await bus.execute({
  action: 'chat.private.send',
  senderId: 'self',
  origin: 'self',
  target: identity.adminId,
  text: '在。',
});
```

真实 QQ 发送由宿主实现 `transport.send`。  
非 owner 不能调用；目标默认只允许 owner。
