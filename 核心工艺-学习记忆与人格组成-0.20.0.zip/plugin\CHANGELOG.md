# Changelog

## 0.20.0 — Phase 26

- 表情发送默认无限制
- 新增 stickerDailyLimit / stickerWeeklyLimit / stickerCooldownMin
- 0 = 不限制；默认 0
- 新增 1 项表情额度测试

## 0.19.0 — Phase 25

- after-response 记录 dialogue event
- 新增 public-data-export / scan-release / dedupe-events
- 新增数据收集协议与同意书
- 新增核心说明、风险说明、冲突清理清单
- 停用 owner-identity 与旧 sticker 发送工具

## 0.18.0 — Phase 24

- 新增 QzonePublishAdapter
- 新增 cognition_qzone_publish
- 公共动作确认 + owner-only + 好友可见
- 复制 qzone 内容安全过滤
- 关闭旧 qzone publish 工具
- 新增 1 项发布测试

## 0.17.0 — Phase 23

- 新增 QzoneReadAdapter
- 新增 cognition_qzone_read
- 复用 OneBot get_qzone_feeds，不重写登录
- 只读自己的说说/评论
- 新增 1 项 QQ空间测试

## 0.16.0 — Phase 22

- 新增 XhhReadAdapter
- 新增 cognition_xhh_feed
- 实现小黑盒 hkey 签名
- 信息流真实 API 实测通过
- 新增 1 项小黑盒测试

## 0.15.0 — Phase 21

- 新增 BiliReadAdapter
- 新增 cognition_bili_search / cognition_bili_video
- 视频 view 412 时回退精确 BV 搜索
- 新增 2 项 B站测试

## 0.14.0 — Phase 20

- SelfModel 只读检索验证
- 明确不自动注入
- 新增 1 项检索/不注入测试

## 0.14.0 — Phase 19

- 新增 QQPrivateAdapter
- 新增 cognition_private_send
- owner-only 私聊发送
- 新增 1 项私聊测试

## 0.13.0 — Phase 18

- person-cards.json 小索引，修复 5 秒 hook 超时
- 新增 cognition_self 只读工具
- 认人卡片不再扫描 3831 条事件
- 新增 1 项测试工具注册断言

## 0.12.0 — Phase 17

- PersonStore / RelationshipStore 支持 upsert + 最新记录
- owner 写入 Person/Relationship
- SelfModel v1 初始化
- 新增 owner/self-model 测试

## 0.11.0 — Phase 14

- 新增 QQStickerAdapter
- 新增 cognition_sticker_send 工具
- 通过 ActionBus / Gateway 执行 owner-only 检查
- 真实 QQ 发送等待 adminId 绑定
- 新增 1 项 QQ sticker 测试

## 0.10.0 — Phase 13

- 新增 PersonStore / RelationshipStore
- 导入 21 人 / 21 关系 / 67 条印象
- 新增跨会话认人卡片
- 停用 cross-chat-link
- 停用 context-reuse
- 新增 1 项认人测试

## 0.9.0 — Phase 10

- 顶栏「认知」模块补丁
- 可选小预算 ContextPack 注入，默认关闭
- 新增 `injectContextEnabled` / `injectContextTokens` / `injectContextMaxItems`
- 新增 2 项注入测试

## 0.8.0 — Phase 8 + 顶栏模块

- QQA 顶栏一级入口「认知」
- 顶栏 iframe 懒加载权限面板
- UI 补丁脚本与备份
- 社区安装包 `cognition-core-community-0.8.0.zip`
- QQA host `setup` / `activate` / `deactivate`
- settings -> Gateway
- Gateway snapshot -> `api.storage`
- 注册只读工具 `cognition_status` / `cognition_recall`
- QQA 安装验证：active、panel 200、storage 生成
- 新增 2 项 host 测试

## 0.7.0 — Phase 7

- 新增权限等级 L0–L4
- 新增 11 个功能接口开关
- 新增时间窗、日上限、周上限、冷却
- 新增 Gateway / UsageLedger
- 新增 ActionBus 网关拦截
- 新增 QQA 权限面板
- 新增 manifest 生成器
- 新增 GUI 文档

## 0.6.0 — Phase 6

- 新增 ContextPack / token 预算
- 新增 estimateTokens
- 新增中文使用说明
- 新增兼容性说明
- 新增 token 预算文档
- 新增 4 项 ContextPack 测试

## 0.5.0 — Phase 5

- 新增 MusicAdapter
- 新增 PrivateChatAdapter
- 新增 MockChatTransport
- 新增 createMockHost
- 新增 4 项 Phase 5 测试

## 0.4.0 — Phase 4

- 新增 MockAdapter
- 新增 StickerAdapter
- 新增示例 sticker catalog
- ActionBus 支持 `origin: self`
- 新增 4 项 Adapter 测试

## 0.3.0 — Phase 3

- 新增 ActionBus
- 新增 ActionPolicy
- 新增 owner-only dispatcher
- 新增 action-log.jsonl
- 新增 5 项 Action 测试

## 0.2.0 — Phase 2

- 新增 EpisodeStore
- 新增 CognitionStore（修订追加）
- 新增 SelfModelStore（版本追加）
- 新增 promotion 纯函数
- 新增 5 项 Phase 2 测试
- 冻结导入 3764 条事件

## 0.1.0 — Phase 1

- 新增 IdentityAnchor / Person / Relationship / Event schema
- 新增 EventStore
- 新增旧记忆只读导入
- 新增 P1/P2/P3 常量
- 新增 9 项测试
