import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

function arg(name, fallback = '') {
  const i = process.argv.indexOf(name);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

const appRoot = path.resolve(arg('--app-root', process.env.QQ_AGENT_APP_ROOT || ''));
const dryRun = process.argv.includes('--dry-run');
if (!appRoot) {
  console.error('usage: node scripts/patch-qqa-ui.mjs --app-root "<QQ Agent install dir>" [--dry-run]');
  process.exit(2);
}

const uiDir = path.join(appRoot, 'resources', 'app', 'ui');
const files = {
  html: path.join(uiDir, 'index.html'),
  chrome: path.join(uiDir, 'app', '14-chrome.js'),
  core: path.join(uiDir, 'app', '00-core.js'),
  css: path.join(uiDir, 'style.css'),
};

const marker = 'cognition-core-ui-patch-v1';
const backupDir = path.join(ROOT, 'dist', `qqa-ui-backup-${new Date().toISOString().replace(/[:.]/g, '-')}`);

const sources = {};
for (const [key, file] of Object.entries(files)) {
  sources[key] = await readFile(file, 'utf8');
}

if (Object.values(sources).some((text) => text.includes(marker))) {
  console.log('already patched');
  process.exit(0);
}

let html = sources.html;
const navUsage = html.match(/<button class="nav-item"[^>]*data-top="usage"[\s\S]*?<\/button>/);
if (!navUsage) throw new Error('usage nav button not found');
const cognitionNav = `\n      <!-- ${marker} -->\n      <button class="nav-item" type="button" data-top="cognition" data-tab="cognition" title="认知核心：权限、自主开关与频率限制">\n        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a6 6 0 0 0-3.6 10.8c.5.4.8 1 .8 1.6V17h5.6v-1.6c0-.6.3-1.2.8-1.6A6 6 0 0 0 12 3z" stroke-linejoin="round" /><path d="M9 20h6M10 17v3M14 17v3" stroke-linecap="round" /></svg>认知\n      </button>`;
html = html.replace(navUsage[0], `${navUsage[0]}${cognitionNav}`);

const tabUsage = '<button class="tab" type="button" data-tab="usage"></button>';
if (!html.includes(tabUsage)) throw new Error('usage tab anchor not found');
html = html.replace(tabUsage, `${tabUsage}\n        <button class="tab" type="button" data-tab="cognition"></button>`);

const skillsMarker = '        <!-- 技能视图：从设置页独立出来（原先和模型/聊天设置挤在一起，找不到） -->';
if (!html.includes(skillsMarker)) throw new Error('skills view marker not found');
const cognitionView = `        <!-- cognition-core topbar view -->\n        <section id="view-cognition" class="view">\n          <iframe id="cognition-frame" class="cognition-frame" data-src="/plugin-panel/cognition-core/panel/overview.html" title="认知核心权限面板" loading="lazy"></iframe>\n        </section>\n\n`;
html = html.replace(skillsMarker, `${cognitionView}${skillsMarker}`);

let chrome = sources.chrome;
const usageGroup = "    { key: 'usage',    label: '用量', home: 'usage',    subs: ['usage'] },";
if (!chrome.includes(usageGroup)) throw new Error('usage group not found');
chrome = chrome.replace(usageGroup, `${usageGroup}\n    { key: 'cognition', label: '认知', home: 'cognition', subs: ['cognition'] }, // ${marker}`);

let core = sources.core;
const usageHook = "  if (name === 'usage') loadUsageView({ force: true });";
if (!core.includes(usageHook)) throw new Error('usage hook not found');
core = core.replace(usageHook, `${usageHook}\n  if (name === 'cognition') {\n    const frame = document.querySelector('#cognition-frame');\n    if (frame && !frame.getAttribute('src')) frame.src = frame.dataset.src || '';\n  } // ${marker}`);

let css = sources.css;
css += `\n/* ${marker} */\n#view-cognition { padding: 0; overflow: hidden; }\n#view-cognition .cognition-frame { display: block; width: 100%; height: 100%; border: 0; background: transparent; }\n`;

if (dryRun) {
  console.log('dry-run: patch is valid');
  process.exit(0);
}

await mkdir(backupDir, { recursive: true });
for (const [key, file] of Object.entries(files)) {
  await copyFile(file, path.join(backupDir, path.basename(file)));
}
await writeFile(files.html, html, 'utf8');
await writeFile(files.chrome, chrome, 'utf8');
await writeFile(files.core, core, 'utf8');
await writeFile(files.css, css, 'utf8');
console.log(`patched: ${uiDir}`);
console.log(`backup: ${backupDir}`);
console.log('restart QQ Agent to see 认知 in the top bar.');
