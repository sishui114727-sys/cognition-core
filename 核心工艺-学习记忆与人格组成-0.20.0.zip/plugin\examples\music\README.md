# Music Adapter Example

把 `catalog.example.json` 复制成 `catalog.json`，把音频文件放同目录。

```js
import { ActionBus, MusicAdapter } from 'cognition-core';

const bus = new ActionBus({ dataDir, identity });
new MusicAdapter({ catalogFile: './catalog.json' }).register(bus);

await bus.execute({
  action: 'music.play',
  senderId: 'self',
  origin: 'self',
  tags: ['calm'],
});
```

Adapter 只返回音频路径和元数据，不播放。  
真实播放由宿主 Adapter 完成。
