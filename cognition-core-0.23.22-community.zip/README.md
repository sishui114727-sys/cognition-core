# cognition-core 0.23.22（社区版）

本地优先的**认知与身份核心**，QQ Agent（QQA）插件。它不是人设卡，不是云记忆服务。

## 先读这三份

    docs/发布说明-0.23.22.md        单页版：是什么、多了什么、怎么装、边界在哪
    docs/社区版使用说明.zh-CN.md    怎么装、怎么配、怎么用、怎么报问题
    docs/炸机说明（必看！！！！）.md  装之前必须清掉的插件与配置

## 三句话说明它是什么

    身份 → 身份锚点 / 人物 / 关系      经历 → 事件（append-only）
    长期认识 → 认知（可改判、可取代）   自我描述 → 版本化的自我模型
    行动 → 权限等级 + 时间窗 + 限额 + 冷却 + 审计

不默认注入人设卡；每轮只注入本轮话题相关的少量记忆；数据全部留在本地，默认不联网。

## 安装

    plugin/  →  <QQA 安装目录>\resources\app\plugins\cognition-core
    重启 QQ Agent，设置里填主人 QQ，打开「启用认知核心」

详见 `docs/社区版使用说明.zh-CN.md`。

## 目录

    plugin/     插件本体（index.js 与 src/ 已混淆）
    docs/       使用说明、炸机说明、完成度说明、更新说明、数据收集协议、设计文档
    scripts/    聚合数据导出脚本（public-data-export.mjs）
    LICENSE     专有软件声明（UNLICENSED，禁止二次开发）
    NOTICE.zh-CN.md  关于许可与二次开发

## 许可

专有软件（package.json 里 license 为 UNLICENSED）：允许在你自己的设备上运行，
**禁止修改、反混淆、再分发与二次开发**。详见 NOTICE.zh-CN.md。
